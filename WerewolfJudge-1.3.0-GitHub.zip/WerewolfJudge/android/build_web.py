#!/usr/bin/env python3
"""Integrate additive tools into the preserved single-file judge app."""
from pathlib import Path
import shutil

root=Path(__file__).resolve().parent
web=root/'web'
source=(web/'base.html').read_text()
def replace(old,new,count=1):
    global source
    actual=source.count(old)
    if actual!=count:
        raise RuntimeError(f'Expected {count} occurrences, got {actual}: {old[:90]}')
    source=source.replace(old,new)

replace('</style>',(web/'tools.css').read_text()+'\n</style>')
replace('<div class="logo">🐺 狼人杀法官助手</div>','<div class="logo"><span>🐺</span><span class="logo-text">狼人杀法官助手</span></div>')
replace('    <button class="btn blue small" id="btnLog">📜 日志</button>\n    <button class="btn purple small" id="btnSetup">⚙️ 设置</button>', '''    <button class="btn orange small toolbar-button" id="btnVote" hidden><span class="toolbar-icon">🗳️</span><span class="toolbar-label">计票</span></button>
    <button class="btn green small toolbar-button" id="btnNumbers" hidden><span class="toolbar-icon">🔢</span><span class="toolbar-label">号码</span></button>
    <button class="btn blue small toolbar-button" id="btnTimer" hidden><span class="toolbar-icon">⏱️</span><span class="toolbar-label">计时</span></button>
    <button class="btn blue small toolbar-button" id="btnLog"><span class="toolbar-icon">📜</span><span class="toolbar-label">日志</span></button>
    <button class="btn purple small toolbar-button" id="btnSetup"><span class="toolbar-icon">⚙️</span><span class="toolbar-label">设置</span></button>''')
replace('<div id="toast"></div>',(web/'tools-ui.html').read_text()+'\n<div id="toast"></div>')
replace('      <option value="翻牌">🤕 白痴翻牌</option>','      <option value="翻牌">🤕 白痴翻牌</option>\n      <option value="投票">🗳️ 投票记录</option>')
replace("  started:false, players:[], round:1, phase:'night',","  started:false, players:[], round:1, phase:'night', gameId:null, identityPending:false, finished:false, sheriffId:null,")
replace("function renderAll(){ renderStatus(); renderGrid(); renderPhase(); document.body.className = state.phase; }", "function renderAll(){ document.body.classList.remove('day','night'); document.body.classList.add(state.phase); renderStatus(); renderGrid(); renderPhase(); renderToolChrome(); }")
replace("  const alive=state.players.filter(p=>p.alive);", "  const alive=state.players.filter(p=>p.alive);")
replace("    tonight+\n    `<div class=\"hint\">", "    tonight+\n    (state.identityPending?'<span class=\"chip\">✏️ 身份待标记</span>':'')+\n    (state.finished?'<span class=\"chip\">📋 本局已结束</span>':'')+\n    `<div class=\"hint\">")
replace("if(sum===cfg.count && (cfg.roles['狼人']||0)>0)","if(sum===cfg.count)")
replace("st.textContent = sum!==cfg.count ? '✘ 人数不匹配' : '✘ 至少1只狼';", "st.textContent = '✘ 人数不匹配';")
replace("  if(cnt['狼人']>0){ st.textContent='✔ 可以开局'; st.className='ok'; }\n  else { st.textContent='✘ 至少1只狼'; st.className='bad'; }", "  if(cfg.players.length===cfg.count && cfg.players.every(p=>ROLES.includes(p.role))){ st.textContent='✔ 可以开局'; st.className='ok'; }\n  else { st.textContent='✘ 请检查名单'; st.className='bad'; }")
replace("  if((cfg.roles['狼人']||0)<1){ toast('至少需要 1 只狼人哦'); return; }\n",'')
replace("  if(cnt['狼人']<1){ toast('名单里至少需要 1 只狼人哦'); return; }", "  if(cfg.players.length!==cfg.count || !cfg.players.every(p=>ROLES.includes(p.role))){ toast('请检查玩家人数和身份'); return; }")
replace("    state={...DEFAULT_STATE(), started:true, players, logSeq:1};", "    state={...DEFAULT_STATE(), started:true, players, logSeq:1, gameId:'game-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7),identityPending:!players.some(isWolfRole)};\n    resetToolForGame();")
replace("    snapshot(); state=DEFAULT_STATE(); save(); renderAll(); closeSetup(); toast('已清空，重新设置吧');", "    snapshot(); pauseTimerSilently();returnToGame();state=DEFAULT_STATE();save();renderAll();closeSetup();toast('已清空，重新设置吧');")
replace("  p.idiotRevealed=false;", "  p.idiotRevealed=false;\n  if(isWolfRole(p)) state.identityPending=false;")
replace('    <div class="field"><label>身份角色</label>', '    <div style="margin-bottom:14px"><button class="btn blue" onclick="showPlayerNumber(${p.id},\'game\')">🔢 展示玩家号码</button></div>\n    <div class="field"><label>身份角色</label>')
replace('    <button class="btn red" onclick="confirmReset()">🗑️ 清空重开</button>', '''    <button class="btn blue" onclick="loadVillagers()">👤 全村民直接开局</button>
    <div class="two-col"><button class="btn purple" id="btnEndGame" onclick="requestEndGame()">结束并结算</button><button class="btn ghost" id="btnViewSettlement" onclick="openSettlement(false)">查看本局结算</button></div>
    <button class="btn red" onclick="confirmReset()">🗑️ 清空重开</button>
    <div class="app-credit">狼人杀法官助手 · v1.3.0<br>作者：Rat</div>''')
replace('/* ================= 启动 ================= */', (web/'tools.js').read_text()+'\n'+(web/'roles.js').read_text()+'''\nfunction loadVillagers(){ensureCfgPlayers();cfg.roles={};ROLES.forEach(r=>cfg.roles[r]=r==='平民'?cfg.count:0);cfg.players.forEach(p=>p.role='平民');startGame();}\n/* ================= 启动 ================= */''')
replace('load();\nensureCfgPlayers();','load();\nnormalizeRoleState();\nensureCfgPlayers();')
replace('  <h3>⚙️ 对局设置</h3>','  <div class="sheet-tool-heading"><h3>⚙️ 对局设置</h3><button class="btn blue tool-back" onclick="returnToGame()" data-game-back>↩ 返回对局</button></div>')
replace('  <h3>📜 行动日志</h3>','  <div class="sheet-tool-heading"><h3>📜 行动日志</h3><button class="btn blue tool-back" onclick="returnToGame()" data-game-back>↩ 返回对局</button></div>')
replace('      <option value="翻牌">🤕 白痴翻牌</option>', '      <option value="翻牌">🤕 白痴翻牌</option>\n      <option value="技能">⚔️ 角色技能</option>\n      <option value="警长">⭐ 警长变更</option>')
replace("if(!state.started){ setTimeout(openSetup,400); }", "renderTimerInputs();renderTimerPresets();renderTimerClock();timerTick();syncNativeTimer();\nif(!state.started){ setTimeout(openSetup,400); }")
out=root/'assets'/'index.html'
out.parent.mkdir(exist_ok=True)
out.write_text(source)
print(out)
