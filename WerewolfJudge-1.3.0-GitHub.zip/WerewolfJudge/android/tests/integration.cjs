const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
let playwright;try{playwright=require('playwright');}catch(e){playwright=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright');}
const {chromium}=playwright;
const project=path.resolve(__dirname,'..'),work=path.resolve(project,'..');
const html=()=>fs.readFileSync(path.join(project,'assets/index.html'),'utf8');
const bundled=path.join(work,'toolchain/headless-shell/chrome-headless-shell-linux64/chrome-headless-shell');
const binary=process.env.WW_BROWSER_BINARY||(fs.existsSync(bundled)?bundled:chromium.executablePath());
const font=path.join(work,'toolchain/NotoSansCJKsc-Regular.otf');
const cases=[],errors=[];
function fixture(n=8){const roles=['狼人','猎人','平民','女巫','平民','预言家','白痴','狼人'];return {started:true,players:Array.from({length:n},(_,i)=>({id:i+1,name:String(i+1),role:roles[i%8],alive:![2,5].includes(i+1),cause:[2,5].includes(i+1)?i+1===2?'狼刀':'放逐':null,deathRound:i+1===2?'第1夜':i+1===5?'第1天':null,note:'',idiotRevealed:false})),round:2,phase:'day',potions:{antidote:true,poison:true},logs:[],logSeq:1,nights:{}};}
async function test(name,fn){if(process.env.WW_TEST_FILTER&&!name.includes(process.env.WW_TEST_FILTER))return;await fn();cases.push(name);console.log('PASS',name);}
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:binary,args:['--no-sandbox','--disable-dev-shm-usage']});
 async function app(state,viewport={width:393,height:800}){
  const context=await browser.newContext({viewport,hasTouch:true});
  if(state)await context.addInitScript(s=>{if(!localStorage.getItem('ww-judge-v1'))localStorage.setItem('ww-judge-v1',JSON.stringify(s));},state);
  const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
  await page.route('**/*',route=>route.request().url().endsWith('/test-cjk.otf')?route.fulfill({contentType:'font/otf',body:fs.readFileSync(font)}):route.fulfill({contentType:'text/html',body:html()}));
  await page.goto('https://appassets.androidplatform.net/');
  if(fs.existsSync(font)){await page.addStyleTag({content:"@font-face{font-family:TestCJK;src:url('/test-cjk.otf')}body,button,input,select{font-family:TestCJK,system-ui!important}"});await page.evaluate(()=>document.fonts.ready);}
  return {page,context};
 }
 await test('全村民配置可以从设置直接开始，并保持原主页操作',async()=>{
  const {page:p,context}=await app();await p.locator('#setupSheet').waitFor({state:'visible'});await p.locator('button[onclick="loadVillagers()"]').click();
  assert.equal(await p.evaluate(()=>state.started),true);assert.equal(await p.evaluate(()=>state.players.every(p=>p.role==='平民')),true);assert.equal(await p.evaluate(()=>state.identityPending),true);assert.equal(await p.locator('#grid .card').count(),12);
  await p.locator('#btnVote').click();assert.equal(await p.locator('#voteTargets button').count(),12);await p.locator('#votePage .tool-back').click();assert.equal(await p.locator('#grid').isVisible(),true);await context.close();
 });
 await test('多选投向、按顺序跳过出局者、平票结算、保存及旧存档兼容',async()=>{
  const {page:p,context}=await app(fixture());await p.locator('#btnVote').click();
  assert.equal(await p.locator('[data-target="1"]').isDisabled(),true);assert.equal(await p.locator('[data-target="2"]').isDisabled(),true);
  for(const id of [3,4,6])await p.locator(`[data-target="${id}"]`).click();
  assert.deepEqual(await p.evaluate(()=>currentDraft().ballots[1].targets),[3,4,6]);
  await p.locator('[data-target="6"]').click();await p.locator('[data-target="6"]').click();
  const rounds=[[3,[6]],[4,[3]],[6,[3]],[7,[6]],[8,[3,6]]];
  for(const [id,targets] of rounds){await p.locator('#voteNext').click();assert.equal(await p.locator('#voterAvatar').innerText(),String(id));for(const target of targets)await p.locator(`[data-target="${target}"]`).click();}
  await p.locator('button[onclick="saveVoteRound()"]').click();assert.match(await p.locator('#voteResultBanner').innerText(),/平票.*3号、6号.*4票/);
  const stored=await p.evaluate(()=>{const g=gameTools(),t=tallyVotes(g.polls[0]);return {polls:g.polls.length,total3:t.incoming[3].length,total6:t.incoming[6].length};});assert.deepEqual(stored,{polls:1,total3:4,total6:4});
  await p.reload();await p.locator('#btnVote').click();assert.equal(await p.locator('#voteResultPage').isVisible(),true);assert.match(await p.locator('#voteResultBanner').innerText(),/平票/);
  await p.evaluate(()=>{state.players.find(x=>x.id===3).alive=false;state.players.find(x=>x.id===3).cause='枪杀';save();});
  assert.equal(await p.evaluate(()=>tallyVotes(gameTools().polls[0]).incoming[3].length),4);
  await p.locator('button[onclick="editSavedVote()"]').click();await p.locator('button[onclick="confirmClearVotes()"]').click();await p.locator('#confirmBox button').first().click();assert.equal(await p.evaluate(()=>currentDraft().ballots[1].targets.length),3);
  await p.locator('button[onclick="confirmClearVotes()"]').click();await p.locator('#cfOk').click();assert.deepEqual(await p.evaluate(()=>currentDraft().ballots),{});assert.equal(await p.evaluate(()=>gameTools().polls.length),1);
  await p.locator('#voteAbstain').click();await p.locator('button[onclick="saveVoteRound()"]').click();assert.equal(await p.evaluate(()=>gameTools().polls.length),2);assert.match(await p.locator('#voteResultBanner').innerText(),/尚无有效选票/);
  const second=await p.evaluate(()=>gameTools().polls[1]);assert.equal(second.ballots[1].abstain,true);assert.equal(second.ballots[4],undefined);
  await p.reload();await p.locator('#btnVote').click();assert.match(await p.locator('#voteResultRound').innerText(),/第2轮/);
  await p.locator('#voteResultPage .tool-back').click();await p.locator('#btnSetup').click();await p.locator('#btnViewSettlement').click();await p.locator('#cfOk').click();assert.equal(await p.locator('.poll-history-button').count(),2);assert.equal(await p.locator('.poll-history-button.tied').count(),1);
  await context.close();
 });
 await test('投票撤销独立于对局撤销，白痴投票限制与原有翻牌逻辑保留',async()=>{
  const {page:p,context}=await app(fixture());await p.locator('#btnVote').click();const historyCount=await p.evaluate(()=>history.length);await p.locator('[data-target="3"]').click();await p.locator('#voteUndo').click();assert.deepEqual(await p.evaluate(()=>currentDraft().ballots),{});assert.equal(await p.evaluate(()=>history.length),historyCount);
  await p.locator('#votePage .tool-back').click();await p.evaluate(()=>openSheet(7));await p.locator('button[onclick="doAction(\'票死\')"]').click();assert.equal(await p.evaluate(()=>state.players[6].alive&&state.players[6].idiotRevealed),true);
  await p.locator('#btnVote').click();assert.equal(await p.locator('[data-target="7"]').isDisabled(),true);await p.locator('#votePage .tool-back').click();await p.locator('#btnUndo').click();assert.equal(await p.evaluate(()=>state.players[6].idiotRevealed),false);await context.close();
 });
 await test('号码牌支持卡片入口、切换、全屏展示及返回对局',async()=>{
  const {page:p,context}=await app(fixture());await p.evaluate(()=>openSheet(6));await p.getByRole('button',{name:'展示玩家号码',exact:false}).click();assert.equal(await p.locator('#numberDigit').innerText(),'6');await p.locator('#numberNext').click();assert.equal(await p.locator('#numberDigit').innerText(),'7');await p.evaluate(()=>handleAppBack());assert.equal(await p.locator('#numberScreen').isHidden(),true);assert.equal(await p.locator('#grid').isVisible(),true);await p.locator('#btnNumbers').click();assert.equal(await p.locator('#numberPickerGrid .vote-tile').count(),8);await context.close();
 });
 await test('分钟秒钟加减与进位、暂停续计、跨页面到时、预设管理',async()=>{
  const {page:p,context}=await app(fixture());await p.locator('#btnTimer').click();await p.evaluate(()=>updateDuration(59));await p.locator('[data-hold-seconds="1"]').click();assert.equal(await p.locator('#timerMinutes').inputValue(),'1');assert.equal(await p.locator('#timerSeconds').inputValue(),'0');
  await p.evaluate(()=>updateDuration(5));await p.locator('#timerStart').click();await p.waitForTimeout(250);await p.locator('#timerStart').click();const before=await p.evaluate(()=>timerRemaining());await p.waitForTimeout(350);const after=await p.evaluate(()=>timerRemaining());assert.ok(Math.abs(before-after)<30);
  await p.locator('#timerStart').click();await p.evaluate(()=>{extra.timer.anchor-=7000;timerTick();});assert.equal(await p.evaluate(()=>extra.timer.status),'done');await p.locator('#timerSheet .sheet-close').click();await p.locator('#btnVote').click();assert.equal(await p.evaluate(()=>extra.timer.status),'done');await p.locator('#btnTimer').click();assert.match(await p.locator('#timerState').innerText(),/时间到/);
  await p.evaluate(()=>updateDuration(3));const old=await p.evaluate(()=>extra.timer.presets.length);await p.locator('button[onclick="saveTimerPreset()"]').click();assert.equal(await p.evaluate(()=>extra.timer.presets.length),old+1);const id=await p.evaluate(()=>extra.timer.presets.at(-1).id);await p.locator(`[data-preset="${id}"]`).dispatchEvent('contextmenu');await p.locator('#presetName').fill('测试发言');await p.locator('button[onclick="applyTimerPresetEdit()"]').click();assert.equal(await p.evaluate(()=>extra.timer.presets.at(-1).name),'测试发言');await p.locator(`[data-preset="${id}"]`).click();assert.equal(await p.evaluate(()=>extra.timer.status),'running');
  await p.locator('#timerStart').click();await p.reload();assert.equal(await p.evaluate(()=>extra.timer.status),'paused');assert.equal(await p.evaluate(()=>extra.timer.presets.at(-1).name),'测试发言');await context.close();
 });
 await test('投票及结果在12/18人和窄屏、横屏下均无需页面滚动',async()=>{
  const {page:p,context}=await app(fixture());const dimensions=[[320,568],[360,640],[393,740],[393,800],[412,915],[640,360],[800,480]];
  const failures=[];
  for(const [width,height] of dimensions)for(const n of [12,18]){
   await p.setViewportSize({width,height});const f=fixture(n);f.players.forEach(p=>{p.name='玩家'+p.id;p.alive=true;p.cause=null;p.deathRound=null;});f.gameId='layout-'+width+'-'+height+'-'+n;
   await p.evaluate(s=>{returnToGame();state=s;renderAll();},f);await p.locator('#btnVote').click();await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
   const edit=await measure(p,'voteTargets');if(edit.bad.length||edit.scroll)failures.push({width,height,n,page:'editor',...edit});
   await p.locator('button[onclick="saveVoteRound()"]').click();await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));const result=await measure(p,'voteResultGrid');if(result.bad.length||result.scroll)failures.push({width,height,n,page:'result',...result});
  }
  fs.writeFileSync(path.join(work,'layout-report.json'),JSON.stringify(failures,null,2));assert.deepEqual(failures,[]);
  await p.setViewportSize({width:393,height:800});await p.evaluate(()=>{returnToGame();state.players=state.players.slice(0,12);renderAll();openVoting();});await p.screenshot({path:path.join(work,'vote-final-screen.png'),fullPage:true});await context.close();
 });
 async function measure(p,id){return p.evaluate(id=>{const grid=document.getElementById(id),r=grid.getBoundingClientRect(),bad=[];Array.from(grid.children).forEach((tile,i)=>{const t=tile.getBoundingClientRect();if(t.top<r.top-1||t.bottom>r.bottom+1||t.left<r.left-1||t.right>r.right+1)bad.push({id:i+1,reason:'tile outside grid'});for(const el of tile.querySelectorAll('.avatar,.tile-name,.rolebadge,.tile-state,.vote-total,.vote-result-source')){if(!el.getClientRects().length)continue;const e=el.getBoundingClientRect();if(e.top<t.top+1||e.bottom>t.bottom-1||e.left<t.left+1||e.right>t.right-1)bad.push({id:i+1,reason:'content clipped',element:el.className,tileH:t.height,childH:e.height});}});return {scroll:document.documentElement.scrollHeight>innerHeight+1||document.documentElement.scrollWidth>innerWidth+1,bad,gridHeight:r.height,columns:getComputedStyle(grid).getPropertyValue('--grid-cols')};},id);}
 assert.deepEqual(errors,[]);fs.writeFileSync(path.join(project,'tests/report.json'),JSON.stringify({version:'1.3.0',passed:cases,scriptErrors:errors,deviceTested:false},null,2));console.log('All integration groups passed.');await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
