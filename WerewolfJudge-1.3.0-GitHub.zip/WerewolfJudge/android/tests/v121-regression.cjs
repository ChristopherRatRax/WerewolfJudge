const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
let pw;try{pw=require('playwright');}catch(e){pw=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright');}
const root=path.resolve(__dirname,'..'),work=path.resolve(root,'..');let browser;const passed=[],errors=[];
function fixture(phase='night'){return {started:true,gameId:'v121-'+Math.random(),players:['白痴','狼美人','黑狼王','平民','女巫','狼人'].map((role,i)=>({id:i+1,name:'旧昵称'+(i+1),role,alive:true,cause:null,deathRound:null,idiotRevealed:false,note:''})),round:1,phase,nights:{},potions:{poison:true,antidote:true},logs:[],logSeq:1};}
async function app(state=fixture(),bridge='none'){
 const context=await browser.newContext({viewport:{width:393,height:800},hasTouch:true});
 await context.addInitScript(({state,bridge})=>{
  if(state&&!localStorage.getItem('ww-judge-v1'))localStorage.setItem('ww-judge-v1',JSON.stringify(state));
  window.__beeps=0;window.__vibrations=[];window.__alerts=[];window.__schedules=[];
  Object.defineProperty(navigator,'vibrate',{value:p=>{window.__vibrations.push(p);return true;},configurable:true});
  const A=window.AudioContext||window.webkitAudioContext;
  if(A){const create=A.prototype.createOscillator;A.prototype.createOscillator=function(){const node=create.call(this),start=node.start.bind(node);node.start=(...args)=>{window.__beeps++;return start(...args);};return node;};}
  if(bridge!=='none')window.AndroidHost={setKeepAwake(){},setNightMode(){},scheduleTimer:(...args)=>window.__schedules.push(args),alertTimer:(...args)=>{if(bridge==='throw')throw Error('bridge unavailable');window.__alerts.push(args);}};
 },{state,bridge});
 const p=await context.newPage();p.on('pageerror',e=>errors.push(e.message));await p.route('**/*',r=>r.fulfill({contentType:'text/html',body:fs.readFileSync(path.join(root,'assets/index.html'),'utf8')}));await p.goto('https://appassets.androidplatform.net');await p.evaluate(()=>extra.timer.countdownSound=false);return {p,context};
}
async function player(p,id){await p.evaluate(id=>openSheet(id),id);}
async function act(p,id,type){await player(p,id);await p.locator(`button[onclick="doAction('${type}')"]`).click();}
async function test(name,fn){if(process.env.WW_TEST_FILTER&&!name.includes(process.env.WW_TEST_FILTER))return;await fn();passed.push(name);console.log('PASS',name);}
(async()=>{
 browser=await pw.chromium.launch({executablePath:process.env.WW_BROWSER_BINARY||(fs.existsSync(path.join(work,'toolchain/headless-shell/chrome-headless-shell-linux64/chrome-headless-shell'))?path.join(work,'toolchain/headless-shell/chrome-headless-shell-linux64/chrome-headless-shell'):pw.chromium.executablePath()),args:['--no-sandbox','--disable-dev-shm-usage']});
 await test('删除昵称输入，旧对局及旧投票统一使用号码，新对局不再保存昵称',async()=>{
  const {p,context}=await app();assert.equal(await p.locator('#grid').innerText().then(t=>t.includes('旧昵称')),false);
  await p.locator('#btnSetup').click();assert.equal(await p.locator('#playerRows input').count(),0);assert.equal(await p.locator('#playerRows select').count(),6);await p.evaluate(()=>closeSetup());await player(p,1);assert.equal(await p.locator('#editName').count(),0);assert.equal((await p.locator('#sheetContent').innerText()).includes('旧昵称'),false);await p.evaluate(()=>closeSheet());
  await p.locator('#btnVote').click();assert.equal((await p.locator('#votePage').innerText()).includes('旧昵称'),false);await p.evaluate(()=>{currentDraft().ballots={1:{targets:[4],abstain:false}};saveVoteRound();});assert.equal((await p.locator('#voteResultPage').innerText()).includes('旧昵称'),false);await p.evaluate(()=>showPollIncoming(gameTools().polls[0].id,4));assert.equal((await p.locator('#pollDetailContent').innerText()).includes('旧昵称'),false);await p.evaluate(()=>returnToGame());
  await p.locator('#btnLog').click();assert.equal((await p.locator('#fPlayer').innerText()).includes('旧昵称'),false);await p.evaluate(()=>returnToGame());await p.locator('#btnSetup').click();await p.locator('button[onclick="loadVillagers()"]').click();if(await p.locator('#confirmBox').evaluate(e=>e.classList.contains('show')))await p.locator('#cfOk').click();assert.equal(await p.evaluate(()=>state.players.every(p=>!Object.hasOwn(p,'name'))),true);await context.close();
 });
 await test('独占最高票与并列最高票都高亮，加权票数正确，全零票不高亮',async()=>{
  const f=fixture('day');f.sheriffId=1;const {p,context}=await app(f);await p.locator('#btnVote').click();
  await p.evaluate(()=>{currentDraft().ballots={1:{targets:[3],abstain:false},2:{targets:[3],abstain:false},3:{targets:[4],abstain:false}};saveVoteRound();});assert.equal(await p.locator('#voteResultGrid .highest').count(),1);assert.match(await p.locator('#voteResultGrid .highest').getAttribute('aria-label'),/3号，2.5票，最高票/);assert.equal(await p.locator('#voteResultGrid .tied').count(),0);
  const colors=await p.evaluate(()=>[...$('voteResultGrid').children].map(e=>getComputedStyle(e).backgroundColor));assert.notEqual(colors[2],colors[3]);assert.equal(await p.locator('#voteResultBanner').evaluate(e=>e.classList.contains('highest')),true);
  await p.evaluate(()=>{startNextVoteRound();currentDraft().ballots={1:{targets:[3,4],abstain:false},2:{targets:[3],abstain:false},3:{targets:[4],abstain:false}};saveVoteRound();});assert.equal(await p.locator('#voteResultGrid .highest.tied').count(),2);assert.match(await p.locator('#voteResultBanner').innerText(),/各2.5票/);
  await p.evaluate(()=>{startNextVoteRound();saveVoteRound();});assert.equal(await p.locator('#voteResultGrid .highest').count(),0);assert.equal(await p.locator('#voteResultBanner').evaluate(e=>e.classList.contains('highest')),false);await context.close();
 });
 await test('赐死和复活直接放在原动作宫格，普通状态和日志，无特殊区域，支持撤销',async()=>{
  const {p,context}=await app();await player(p,1);
  assert.equal(await p.locator('button[onclick="doAction(\'神的赐死\')"]').evaluate(e=>e.parentElement===document.querySelector('button[onclick="doAction(\'刀死\')"]').parentElement),true);
  assert.equal(await p.locator('button[onclick="doAction(\'神的复活\')"]').evaluate(e=>e.parentElement===document.querySelector('button[onclick="doAction(\'毒死\')"]').parentElement),true);
  assert.equal((await p.locator('#sheetContent').innerText()).includes('神的'),false);await p.locator('button[onclick="doAction(\'神的赐死\')"]').click();assert.deepEqual(await p.evaluate(()=>({alive:state.players[0].alive,cause:state.players[0].cause,revealed:state.players[0].idiotRevealed,action:state.logs.at(-1).action})),{alive:false,cause:'死亡',revealed:false,action:'死亡'});
  await p.locator('#btnUndo').click();assert.equal(await p.evaluate(()=>state.players[0].alive),true);await act(p,1,'神的赐死');await act(p,1,'神的复活');assert.equal(await p.evaluate(()=>state.players[0].alive&&state.players[0].cause===null&&state.players[0].deathRound===null),true);await p.locator('#btnUndo').click();assert.equal(await p.evaluate(()=>state.players[0].cause),'死亡');await context.close();
 });
 await test('无条件修正不受守护或毒药影响，夜间重算不反复判死，新发生的死亡仍有效',async()=>{
  const {p,context}=await app();await act(p,1,'守护');await act(p,1,'神的赐死');assert.equal(await p.evaluate(()=>state.players[0].alive),false);await act(p,4,'刀死');assert.equal(await p.evaluate(()=>state.players[0].cause),'死亡');
  await act(p,4,'毒死');assert.equal(await p.evaluate(()=>state.potions.poison),false);await act(p,4,'神的复活');assert.equal(await p.evaluate(()=>state.players[3].alive&&state.nights[1].knife===null&&state.nights[1].poison===null&&!state.potions.poison),true);
  await act(p,5,'守护');assert.equal(await p.evaluate(()=>state.players[3].alive),true);await act(p,4,'刀死');assert.equal(await p.evaluate(()=>state.players[3].alive),false);assert.equal(await p.evaluate(()=>state.players[3].cause),'狼刀');await context.close();
 });
 await test('赐死不发动黑狼王或狼美人技能，复活只改变选中者且可覆盖殉情',async()=>{
  const f=fixture();f.players[1].charms={1:3};const {p,context}=await app(f);await act(p,2,'毒死');assert.equal(await p.evaluate(()=>state.players[2].cause),'殉情');await act(p,3,'神的复活');await act(p,4,'守护');assert.equal(await p.evaluate(()=>state.players[2].alive&&!state.players[1].alive),true);
  await act(p,2,'神的复活');assert.equal(await p.evaluate(()=>state.players[1].alive&&state.players[2].alive),true);await act(p,2,'神的赐死');assert.equal(await p.evaluate(()=>state.players[2].alive),true);await act(p,3,'神的赐死');assert.equal(await p.evaluate(()=>canWolfKingShoot(state.players[2])),false);await p.reload();await p.evaluate(()=>resolveNight());assert.equal(await p.evaluate(()=>state.players[2].cause),'死亡');await context.close();
 });
 await test('到时通过原生桥发送声音和振动，原生回调与网页到时不重复提醒',async()=>{
  const {p,context}=await app(fixture(),'ok');await p.locator('#btnTimer').click();await p.evaluate(()=>updateDuration(.4));await p.locator('#timerStart').click();await p.locator('#timerSheet .tool-back').click();await p.waitForFunction(()=>extra.timer.status==='done');
  assert.equal(await p.evaluate(()=>__alerts.length),1);assert.deepEqual(await p.evaluate(()=>__alerts[0].slice(1)),[true,true]);assert.equal(await p.evaluate(()=>__beeps),0);await p.evaluate(()=>nativeTimerFired(extra.timer.token));assert.equal(await p.evaluate(()=>__alerts.length),1);
  await p.locator('#btnTimer').click();await p.evaluate(()=>updateDuration(5));await p.locator('#timerStart').click();await p.evaluate(()=>nativeTimerFired(extra.timer.token));assert.equal(await p.evaluate(()=>extra.timer.status),'done');assert.equal(await p.evaluate(()=>__alerts.length),1);assert.equal(await p.evaluate(()=>__beeps),0);await context.close();
 });
 await test('网页实际到时会生成提醒音并请求振动，原生桥异常仍可回退',async()=>{
  for(const bridge of ['none','throw']){const {p,context}=await app(fixture(),bridge);await p.locator('#btnTimer').click();await p.evaluate(()=>updateDuration(.4));await p.locator('#timerStart').click();await p.locator('#timerSheet .tool-back').click();await p.waitForFunction(()=>extra.timer.status==='done'&&__beeps===3);assert.equal(await p.evaluate(()=>audioContext.state),'running');assert.deepEqual(await p.evaluate(()=>__vibrations),[[300,150,300,150,450]]);await p.evaluate(()=>nativeTimerSoundFailed(extra.timer.token));assert.equal(await p.evaluate(()=>__beeps),3);await context.close();}
 });
 await test('测试提醒保留运行计时，遵守声音振动开关，暂停和旧回调不误触发',async()=>{
  const {p,context}=await app(fixture(),'ok');await p.locator('#btnTimer').click();await p.evaluate(()=>updateDuration(5));await p.locator('#timerStart').click();const token=await p.evaluate(()=>extra.timer.token);await p.locator('#timerTestReminder').click();assert.equal(await p.evaluate(()=>extra.timer.status==='running'&&!extra.timer.notified),true);assert.equal(await p.evaluate(()=>extra.timer.token),token);assert.equal(await p.evaluate(()=>__alerts.length),1);
  await p.locator('#timerSound').uncheck();await p.locator('#timerTestReminder').click();assert.deepEqual(await p.evaluate(()=>__alerts.at(-1).slice(1)),[false,true]);await p.locator('#timerVibrate').uncheck();await p.locator('#timerTestReminder').click();assert.equal(await p.evaluate(()=>__alerts.length),2);
  await p.locator('#timerStart').click();assert.equal(await p.evaluate(()=>__schedules.at(-1)[1]<0),true);await p.evaluate(token=>nativeTimerFired(token),token);assert.equal(await p.evaluate(()=>extra.timer.status),'paused');assert.equal(await p.evaluate(()=>__alerts.length),2);await context.close();
 });
 await test('原生播放失败回退网页声音且不重复振动，不改变计时结束状态',async()=>{
  const {p,context}=await app(fixture(),'ok');await p.locator('#btnTimer').click();await p.evaluate(()=>updateDuration(.4));await p.locator('#timerStart').click();await p.waitForFunction(()=>extra.timer.status==='done');assert.equal(await p.evaluate(()=>__alerts.length),1);await p.evaluate(()=>nativeTimerSoundFailed(extra.timer.token));await p.waitForFunction(()=>__beeps===3);assert.equal(await p.evaluate(()=>__vibrations.length),0);await p.evaluate(()=>nativeTimerSoundFailed(extra.timer.token));assert.equal(await p.evaluate(()=>__beeps),3);assert.equal(await p.evaluate(()=>extra.timer.status),'done');await context.close();
 });
 assert.deepEqual(errors,[]);fs.writeFileSync(path.join(root,'tests/v121-regression-report.json'),JSON.stringify({version:'1.3.0',passed,scriptErrors:errors,deviceTested:false,nativeAudioHardwareTested:false},null,2));console.log('All '+passed.length+' v1.2.1 groups passed.');await browser.close();
})().catch(async e=>{console.error(e);if(browser)await browser.close();process.exit(1);});
