const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
let pw;try{pw=require('playwright');}catch(e){pw=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright');}
const root=path.resolve(__dirname,'..'),work=path.resolve(root,'..'),bundled=path.join(work,'toolchain/headless-shell/chrome-headless-shell-linux64/chrome-headless-shell');
let browser;const passed=[],errors=[];
const fixture=()=>({started:true,gameId:'v130-'+Math.random(),players:Array.from({length:12},(_,i)=>({id:i+1,role:['骑士','狼人','女巫','平民'][i%4],alive:true,cause:null,deathRound:null,note:''})),round:1,phase:'day',potions:{poison:true,antidote:true},nights:{},logs:[],logSeq:1});
async function app(bridge='none'){
 const context=await browser.newContext({viewport:{width:393,height:800},hasTouch:true});
 await context.addInitScript(({state,bridge})=>{
  if(!localStorage.getItem('ww-judge-v1'))localStorage.setItem('ww-judge-v1',JSON.stringify(state));
  window.__tones=[];window.__schedules=[];window.__alerts=[];
  Object.defineProperty(navigator,'vibrate',{value:()=>true,configurable:true});
  const A=window.AudioContext||window.webkitAudioContext;if(A){const create=A.prototype.createOscillator;A.prototype.createOscillator=function(){const node=create.call(this),start=node.start.bind(node);node.start=(...args)=>{window.__tones.push(node.frequency.value);return start(...args);};return node;};}
  if(bridge!=='none'){
   window.AndroidHost={scheduleTimer:(...args)=>__schedules.push(['legacy',...args]),setKeepAwake(){},alertTimer:(...args)=>__alerts.push(args)};
   if(bridge!=='legacy')AndroidHost.scheduleTimerV2=(...args)=>{if(bridge==='broken')throw Error('unsupported');__schedules.push(['v2',...args]);};
  }
 },{state:fixture(),bridge});
 const p=await context.newPage();p.on('pageerror',e=>errors.push(e.message));await p.route('**/*',r=>r.fulfill({contentType:'text/html',body:fs.readFileSync(path.join(root,'assets/index.html'),'utf8')}));await p.goto('https://appassets.androidplatform.net');return {p,context};
}
async function test(name,fn){if(process.env.WW_TEST_FILTER&&!name.includes(process.env.WW_TEST_FILTER))return;await fn();passed.push(name);console.log('PASS',name);}
async function start(p,seconds=6,warning=3){await p.locator('#btnTimer').click();await p.evaluate(({seconds,warning})=>{updateDuration(seconds);setTimerWarning(warning);},{seconds,warning});await p.locator('#timerStart').click();await p.waitForFunction(()=>audioContext?.state==='running');}
async function left(p,ms){await p.evaluate(ms=>{extra.timer.anchor=Date.now()-(extra.timer.duration-extra.timer.elapsed-ms);timerTick();},ms);}
(async()=>{
 browser=await pw.chromium.launch({executablePath:process.env.WW_BROWSER_BINARY||(fs.existsSync(bundled)?bundled:pw.chromium.executablePath()),args:['--no-sandbox','--disable-dev-shm-usage']});
 await test('所有号码卡片只保留头像数字，身份状态仍在，设置署名为Rat',async()=>{
  const {p,context}=await app();assert.equal(await p.locator('#grid .pname').count(),0);assert.equal(await p.locator('#grid .avatar').count(),12);assert.equal(await p.locator('#grid .rolebadge').count(),12);
  await p.locator('#btnVote').click();assert.equal(await p.locator('#voteTargets .tile-name').count(),0);assert.equal(await p.locator('#voterName').count(),0);assert.equal(await p.locator('#voteTargets .tile-state').count(),12);await p.locator('[data-target="2"]').click();assert.deepEqual(await p.evaluate(()=>currentDraft().ballots[1].targets),[2]);await p.locator('button[onclick="saveVoteRound()"]').click();assert.equal(await p.locator('#voteResultGrid .tile-name').count(),0);
  await p.evaluate(()=>openNumberPicker());assert.equal(await p.locator('#numberPickerGrid .tile-name').count(),0);await p.evaluate(()=>{returnToGame();openSheet(1);chooseRoleTarget('duel',1);});assert.equal(await p.locator('#roleTargetGrid .tile-name').count(),0);assert.equal(await p.locator('#roleTargetGrid .rolebadge').count(),12);
  await p.evaluate(()=>{returnToGame();openSettlement(true);});assert.equal(await p.locator('#settlementGrid .pname').count(),0);await p.evaluate(()=>{returnToGame();openSetup();});assert.match(await p.locator('.app-credit').innerText(),/v1.3.0.*作者：Rat/s);await context.close();
 });
 await test('从设定剩余秒数开始逐秒短音，同一秒不重复，归零为单次清脆叮',async()=>{
  const {p,context}=await app();await start(p,8,3);await left(p,6000);assert.deepEqual(await p.evaluate(()=>__tones),[]);
  await left(p,3000);await p.evaluate(()=>{for(let i=0;i<5;i++)timerTick();});assert.deepEqual(await p.evaluate(()=>__tones),[820]);
  await left(p,2000);await left(p,1000);await left(p,0);assert.deepEqual(await p.evaluate(()=>__tones),[820,820,820,1760,3525,5285]);assert.equal(await p.evaluate(()=>extra.timer.status),'done');await p.evaluate(()=>timerTick());assert.equal(await p.evaluate(()=>__tones.length),6);await context.close();
 });
 await test('倒数音效单独开关或0秒可关闭短音，结束叮仍保留',async()=>{
  for(const zero of [false,true]){const {p,context}=await app();await start(p,5,zero?0:3);if(!zero)await p.locator('#timerCountdownSound').uncheck();await left(p,2000);assert.deepEqual(await p.evaluate(()=>__tones),[]);await left(p,0);assert.deepEqual(await p.evaluate(()=>__tones),[1760,3525,5285]);await context.close();}
 });
 await test('暂停和重来取消旧倒数，旧原生回调不能发声，下一次计时可再次倒数',async()=>{
  const {p,context}=await app();await start(p);await left(p,3000);const old=await p.evaluate(()=>extra.timer.token);await p.locator('#timerStart').click();await p.evaluate(()=>timerTick());assert.equal(await p.evaluate(()=>__tones.length),1);await p.locator('button[onclick="resetTimer()"]').click();await p.evaluate(old=>nativeCountdownSoundFailed(old,2),old);assert.equal(await p.evaluate(()=>__tones.length),1);await p.locator('#timerStart').click();await left(p,3000);assert.equal(await p.evaluate(()=>__tones.length),2);await context.close();
 });
 await test('正计时没有倒数短音，目标到时仍可播放叮',async()=>{
  const {p,context}=await app();await p.locator('#btnTimer').click();await p.locator('#timerUp').click();assert.equal(await p.locator('#timerCountdownWrap').isHidden(),true);await p.evaluate(()=>{setTimerOption('upTarget',true);updateDuration(3);});await p.locator('#timerStart').click();await left(p,1000);assert.deepEqual(await p.evaluate(()=>__tones),[]);await left(p,0);assert.deepEqual(await p.evaluate(()=>__tones),[1760,3525,5285]);await context.close();
 });
 await test('原生V2接收倒数阈值，网页避免双响，失败回调只回退对应秒数',async()=>{
  const {p,context}=await app('v2');await start(p);const args=await p.evaluate(()=>__schedules.at(-1));assert.equal(args[0],'v2');assert.deepEqual(args.slice(-4),[true,true,true,3]);await left(p,3000);assert.deepEqual(await p.evaluate(()=>__tones),[]);await p.evaluate(()=>{nativeCountdownSoundFailed(extra.timer.token,3);nativeCountdownSoundFailed(extra.timer.token,3);});assert.deepEqual(await p.evaluate(()=>__tones),[820]);await p.evaluate(()=>nativeTimerFired(extra.timer.token));assert.equal(await p.evaluate(()=>extra.timer.status),'done');assert.equal(await p.evaluate(()=>__tones.length),1);assert.equal(await p.evaluate(()=>__schedules.at(-1)[2]<0),true);await context.close();
 });
 await test('旧原生接口或V2异常均保留调度，倒数改用网页短音',async()=>{
  for(const kind of ['legacy','broken']){const {p,context}=await app(kind);await start(p);assert.equal(await p.evaluate(()=>__schedules.at(-1)[0]),'legacy');assert.equal(await p.evaluate(()=>nativeCountdownScheduled),false);await left(p,3000);assert.deepEqual(await p.evaluate(()=>__tones),[820]);await left(p,0);assert.equal(await p.evaluate(()=>__alerts.length),1);await context.close();}
 });
 await test('修改提醒阈值和静音及时重排原生调度，设置重开后保留',async()=>{
  const {p,context}=await app('v2');await start(p,12,3);await p.locator('#timerWarning').fill('7');await p.locator('#timerWarning').dispatchEvent('change');assert.equal(await p.evaluate(()=>__schedules.at(-1).at(-1)),7);await p.locator('#timerSound').uncheck();assert.equal(await p.locator('#timerCountdownSound').isDisabled(),true);assert.equal(await p.evaluate(()=>__schedules.at(-1).at(-2)),false);await p.locator('#timerSound').check();await p.locator('#timerCountdownSound').uncheck();await p.locator('#timerStart').click();await p.reload();await p.locator('#btnTimer').click();assert.equal(await p.locator('#timerWarning').inputValue(),'7');assert.equal(await p.locator('#timerCountdownSound').isChecked(),false);await context.close();
 });
 assert.deepEqual(errors,[]);fs.writeFileSync(path.join(root,'tests/v130-regression-report.json'),JSON.stringify({version:'1.3.0',passed,scriptErrors:errors,deviceTested:false,nativeAudioHardwareTested:false},null,2));console.log('All '+passed.length+' v1.3.0 groups passed.');await browser.close();
})().catch(async e=>{console.error(e);if(browser)await browser.close();process.exit(1);});
