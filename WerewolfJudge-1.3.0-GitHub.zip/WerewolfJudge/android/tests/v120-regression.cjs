const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
let pw;try{pw=require('playwright');}catch(e){pw=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright');}
const root=path.resolve(__dirname,'..'),work=path.resolve(root,'..'),origin='https://appassets.androidplatform.net';
const checks=[],errors=[];let browser;
const roles=['骑士','黑狼王','白狼王','隐狼','狼美人','预言家','女巫','猎人','守卫','白痴','平民','狼人'];
function fixture(n=12,phase='day'){return {started:true,gameId:'qa-'+Math.random(),players:Array.from({length:n},(_,i)=>({id:i+1,name:'玩家'+(i+1),role:roles[i%12],alive:true,cause:null,deathRound:null,note:'',idiotRevealed:false})),round:1,phase,potions:{antidote:true,poison:true},nights:{},logs:[],logSeq:1};}
async function app(state=fixture(),viewport={width:393,height:800}){
 const context=await browser.newContext({viewport,hasTouch:true});
 if(state)await context.addInitScript(s=>{if(!localStorage.getItem('ww-judge-v1'))localStorage.setItem('ww-judge-v1',JSON.stringify(s));},state);
 const p=await context.newPage();p.on('pageerror',e=>errors.push(e.message));
 await p.route('**/*',r=>r.fulfill(r.request().url().endsWith('/test-cjk.otf')?{contentType:'font/otf',body:fs.readFileSync(path.join(work,'toolchain/NotoSansCJKsc-Regular.otf'))}:{contentType:'text/html',body:fs.readFileSync(path.join(root,'assets/index.html'),'utf8')}));
 await p.goto(origin);if(fs.existsSync(path.join(work,'toolchain/NotoSansCJKsc-Regular.otf')))await p.addStyleTag({content:"@font-face{font-family:TestCJK;src:url('/test-cjk.otf')}body,button,input,select{font-family:TestCJK,system-ui!important}"});await p.evaluate(()=>document.fonts.ready);
 return {p,context};
}
async function test(name,fn){if(process.env.WW_TEST_FILTER&&!name.includes(process.env.WW_TEST_FILTER))return;await fn();checks.push(name);console.log('PASS',name);}
async function player(p,id){await p.evaluate(id=>openSheet(id),id);}
async function targetSkill(p,type,actor,target,confirm=true){await player(p,actor);await p.locator(`button[onclick="chooseRoleTarget('${type}',${actor})"]`).click();await p.locator(`[data-role-target="${target}"]`).click();if(confirm&&type!=='charm')await p.locator('#cfOk').click();}
async function outcome(p){return p.evaluate(()=>state.players.map(p=>({id:p.id,alive:p.alive,cause:p.cause})));}
async function frames(p){await p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));}
(async()=>{
 browser=await pw.chromium.launch({executablePath:process.env.WW_BROWSER_BINARY||(fs.existsSync(path.join(work,'toolchain/headless-shell/chrome-headless-shell-linux64/chrome-headless-shell'))?path.join(work,'toolchain/headless-shell/chrome-headless-shell-linux64/chrome-headless-shell'):pw.chromium.executablePath()),args:['--no-sandbox','--disable-dev-shm-usage']});
 await test('五种角色支持模板随机分配，全村民按钮直接开始并只保留号码',async()=>{
  const {p,context}=await app(null);await p.locator('#setupSheet').waitFor({state:'visible'});
  await p.evaluate(()=>{cfg.count=5;ensureCfgPlayers();cfg.roles={白狼王:1,黑狼王:1,骑士:1,隐狼:1,狼美人:1};renderSetup();randomAssignToList();});
  assert.deepEqual((await p.evaluate(()=>cfg.players.map(x=>x.role))).sort(),['白狼王','黑狼王','骑士','隐狼','狼美人'].sort());
  await p.locator('button[onclick="loadVillagers()"]').click();
  assert.equal(await p.evaluate(()=>state.started&&state.players.length===5&&state.players.every(p=>p.role==='平民'&&!Object.hasOwn(p,'name'))),true);assert.equal(await p.locator('#setupSheet').evaluate(el=>el.classList.contains('show')),false);
  await context.close();
 });
 await test('白狼王自爆确认、双人出局和单步撤销，非自爆死因不能带人',async()=>{
  const {p,context}=await app();await targetSkill(p,'blast',3,6,false);await p.locator('#confirmBox button').first().click();assert.equal((await outcome(p)).filter(x=>!x.alive).length,0);
  await p.locator('[data-role-target="6"]').click();await p.locator('#cfOk').click();let o=await outcome(p);assert.deepEqual(o.filter(x=>!x.alive),[{id:3,alive:false,cause:'自爆'},{id:6,alive:false,cause:'白狼王带走'}]);
  assert.equal(await p.evaluate(()=>state.phase),'day');await p.locator('#btnUndo').click();assert.equal((await outcome(p)).filter(x=>!x.alive).length,0);
  await p.evaluate(()=>{state.players[2].alive=false;state.players[2].cause='毒药';openSheet(3);});assert.equal(await p.locator('button[onclick="chooseRoleTarget(\'blast\',3)"]').count(),0);await context.close();
 });
 await test('黑狼王枪杀只允许合法死因，技能和目标可整体撤销且不能重复开枪',async()=>{
  const {p,context}=await app();await player(p,2);await p.locator('button[onclick="doAction(\'票死\')"]').click();await targetSkill(p,'wolfShot',2,6);
  assert.equal(await p.evaluate(()=>state.players[1].wolfShotUsed),true);assert.deepEqual((await outcome(p)).filter(x=>!x.alive).map(x=>x.cause),['放逐','黑狼王枪杀']);
  await player(p,2);assert.equal(await p.locator('button[onclick="chooseRoleTarget(\'wolfShot\',2)"]').count(),0);await p.evaluate(()=>undo());assert.equal(await p.evaluate(()=>state.players[5].alive&&!state.players[1].wolfShotUsed&&!state.players[1].alive),true);
  const forbidden=await p.evaluate(()=>['毒药','狼刀+毒药','殉情','决斗','自爆'].map(cause=>{const p=state.players[1];p.cause=cause;return canWolfKingShoot(p);}));assert.deepEqual(forbidden,[false,false,false,false,false]);await context.close();
 });
 await test('骑士识别隐狼，决斗禁用功能狼技能，误决斗只淘汰骑士',async()=>{
  const {p,context}=await app();await targetSkill(p,'duel',1,4);assert.equal(await p.evaluate(()=>state.players[0].alive&&state.players[0].knightUsed&&!state.players[3].alive&&state.players[3].cause==='决斗'),true);
  await p.locator('#btnUndo').click();await targetSkill(p,'duel',1,2);assert.equal(await p.evaluate(()=>canWolfKingShoot(state.players[1])),false);await p.locator('#btnUndo').click();
  await p.evaluate(()=>{state.players[4].charms={1:6};});await targetSkill(p,'duel',1,5);assert.equal(await p.evaluate(()=>!state.players[4].alive&&state.players[5].alive),true);await p.locator('#btnUndo').click();
  await targetSkill(p,'duel',1,11);assert.equal(await p.evaluate(()=>!state.players[0].alive&&state.players[0].cause==='决斗失败'&&state.players[10].alive),true);await context.close();
 });
 await test('狼美人魅惑、殉情禁枪、撤销和夜间重算保持一致，不能连续两晚重复',async()=>{
  const {p,context}=await app(fixture(12,'night'));await targetSkill(p,'charm',5,2);
  await p.locator('#btnNext').click();await player(p,5);await p.locator('button[onclick="doAction(\'票死\')"]').click();assert.equal(await p.evaluate(()=>state.players[1].cause==='殉情'&&!canWolfKingShoot(state.players[1])),true);
  await p.locator('#btnUndo').click();assert.equal(await p.evaluate(()=>state.players[4].alive&&state.players[1].alive&&state.players[4].charms[1]===2),true);
  await p.locator('#btnNext').click();await player(p,5);await p.locator('button[onclick="chooseRoleTarget(\'charm\',5)"]').click();assert.equal(await p.locator('[data-role-target="2"]').isDisabled(),true);await p.locator('[data-role-target="6"]').click();
  await player(p,5);await p.locator('button[onclick="doAction(\'毒死\')"]').click();assert.equal(await p.evaluate(()=>!state.players[4].alive&&!state.players[5].alive&&state.players[5].cause==='殉情'),true);
  await player(p,9);await p.locator('button[onclick="doAction(\'守护\')"]').click();assert.equal(await p.evaluate(()=>!state.players[4].alive&&!state.players[5].alive&&state.players[5].cause==='殉情'),true);
  await p.reload();assert.equal(await p.evaluate(()=>state.players[5].charmLink.source),5);await context.close();
 });
 await test('接刀隐狼计入狼阵营，最后一狼标记可接刀，不自动结束对局',async()=>{
  const {p,context}=await app();await p.evaluate(()=>{state.players.forEach(p=>{if(p.id!==4&&isWolfRole(p)){p.alive=false;p.cause='放逐';}});save();renderAll();openSheet(4);});
  assert.match(await p.locator('#sheetContent').innerText(),/可接刀/);assert.equal(await p.evaluate(()=>!!state.finished),false);await context.close();
 });
 await test('多狼美人时殉情不继续触发技能，法官复活仅修正选中玩家',async()=>{
  const f=fixture();f.players[4].charms={1:6};f.players[5].role='狼美人';f.players[5].charms={1:11};const {p,context}=await app(f);
  await player(p,5);await p.locator('button[onclick="doAction(\'票死\')"]').click();await p.evaluate(()=>syncCharmConsequences());assert.equal(await p.evaluate(()=>!state.players[5].alive&&state.players[5].cause==='殉情'&&state.players[10].alive),true);
  await player(p,5);await p.locator('button[onclick="doAction(\'神的复活\')"]').click();assert.equal(await p.evaluate(()=>state.players[4].alive&&!state.players[5].alive&&state.players[10].alive),true);await context.close();
 });
 await test('警长并排票权、多选加权、半票平票、撤销与来源人数显示正确',async()=>{
  const {p,context}=await app();await player(p,1);await p.locator('button[onclick="assignSheriff(1)"]').click();await p.evaluate(()=>closeSheet());assert.equal(await p.locator('#grid .sheriff-mark').count(),1);await p.locator('#btnVote').click();
  assert.equal(await p.locator('#sheriffWeight').isVisible(),true);assert.equal(await p.locator('#sheriffWeight select').count(),0);assert.equal(await p.locator('#weight15').getAttribute('aria-pressed'),'true');
  await p.locator('#weight2').click();await p.locator('#voteUndo').click();assert.equal(await p.locator('#weight15').getAttribute('aria-pressed'),'true');assert.equal(await p.evaluate(()=>gameTools().sheriffWeight),1.5);
  for(const id of [3,4])await p.locator(`[data-target="${id}"]`).click();await p.locator('#voteNext').click();assert.equal(await p.locator('#sheriffWeight').isHidden(),true);await p.locator('[data-target="3"]').click();await p.locator('#voteNext').click();await p.locator('[data-target="4"]').click();
  await p.locator('button[onclick="saveVoteRound()"]').click();assert.match(await p.locator('#voteResultBanner').innerText(),/平票.*3号、4号.*2.5票/);assert.equal(await p.locator('#voteResultGrid .tied').count(),2);assert.equal(await p.locator('#voteResultPage .tool-footer button').count(),3);assert.equal(await p.locator('#voteResultPage button').filter({hasText:'本局结算'}).count(),0);
  await p.locator('#voteResultGrid .vote-tile').nth(2).click();assert.match(await p.locator('#pollDetailContent').innerText(),/警长 · 1.5票/);await p.evaluate(()=>closePollDetail());
  await p.locator('#voteResultPage .tool-back').click();await player(p,2);await p.locator('button[onclick="assignSheriff(2)"]').click();await p.locator('#cfOk').click();await p.evaluate(()=>closeSheet());
  assert.equal(await p.evaluate(()=>tallyVotes(gameTools().polls[0]).totals[3]),2.5);await p.locator('#btnVote').click();await p.locator('button[onclick="editSavedVote()"]').click();assert.equal(await p.locator('#sheriffWeight').isVisible(),true);
  await p.locator('#weight2').click();await p.locator('button[onclick="saveVoteRound()"]').click();assert.equal(await p.evaluate(()=>gameTools().polls.length),1);assert.equal(await p.evaluate(()=>tallyVotes(gameTools().polls[0]).totals[3]),3);assert.equal(await p.evaluate(()=>gameTools().polls[0].sheriffId),1);
  await p.reload();await p.locator('#btnVote').click();assert.match(await p.locator('#voteResultBanner').innerText(),/各3票/);await p.locator('button[onclick="openVoteReview()"]').click();assert.equal(await p.locator('#weight2').isDisabled(),true);assert.equal(await p.locator('#voteReviewFooter button').filter({hasText:'本局结算'}).count(),0);await context.close();
 });
 await test('旧投票不追溯加权，警徽撕毁可撤销，白痴翻牌失去投票资格',async()=>{
  const {p,context}=await app();await p.evaluate(()=>{state.sheriffId=1;const poll={id:'legacy',number:1,round:1,phase:'day',roster:clone(state.players),ballots:{1:{targets:[3,4],abstain:false},2:{targets:[3],abstain:false}}};gameTools().polls.push(poll);persistTools();showVoteResult('legacy');});assert.equal(await p.evaluate(()=>tallyVotes(gameTools().polls[0]).totals[3]),2);
  await p.locator('button[onclick="editSavedVote()"]').click();assert.equal(await p.locator('#sheriffWeight').isHidden(),true);await p.locator('button[onclick="saveVoteRound()"]').click();assert.equal(await p.evaluate(()=>tallyVotes(gameTools().polls[0]).totals[3]),2);
  await p.locator('#voteResultPage .tool-back').click();await player(p,1);await p.locator('button[onclick="removeSheriff()"]').click();await p.locator('#cfOk').click();assert.equal(await p.evaluate(()=>state.sheriffId),null);await p.evaluate(()=>undo());assert.equal(await p.evaluate(()=>state.sheriffId),1);
  await p.evaluate(()=>{state.sheriffId=10;openSheet(10);});await p.locator('button[onclick="doAction(\'票死\')"]').click();await p.locator('#btnVote').click();await p.locator('button[onclick="startNextVoteRound()"]').click();assert.equal(await p.locator('[data-target="10"]').isDisabled(),true);await context.close();
 });
 await test('所有返回入口醒目，返回保留草稿和运行计时，本局结算仅从设置进入',async()=>{
  const {p,context}=await app();for(const phase of ['day','night']){await p.evaluate(phase=>{state.phase=phase;renderAll();},phase);for(const id of ['btnVote','btnNumbers','btnTimer','btnLog','btnSetup']){
   await p.locator('#'+id).click();const b=p.locator(({btnVote:'#votePage',btnNumbers:'#numberPickerPage',btnTimer:'#timerSheet',btnLog:'#logSheet',btnSetup:'#setupSheet'})[id]+' .tool-back');assert.equal(await b.count(),1,id);assert.equal(await b.evaluate(el=>getComputedStyle(el).backgroundColor),'rgb(28, 176, 246)');await b.click();assert.equal(await p.locator('#grid').isVisible(),true);
  }}
  await p.locator('#btnTimer').click();await p.locator('#timerStart').click();await p.locator('#timerSheet .tool-back').click();assert.equal(await p.evaluate(()=>extra.timer.status),'running');await p.locator('#btnSetup').click();await p.locator('#btnViewSettlement').click();await p.locator('#cfOk').click();assert.equal(await p.locator('#settlementGrid .card').count(),12);await context.close();
 });
 await test('常用手机12人主页一屏，警长投票在窄屏横屏仍无裁切，保留小屏可读回退',async()=>{
  const {p,context}=await app();const issues=[];
  for(const [width,height] of [[360,740],[393,740],[393,800],[412,915]]){
   await p.setViewportSize({width,height});await p.evaluate(()=>{returnToGame();state=JSON.parse(JSON.stringify(state));state.sheriffId=1;state.players[2].alive=false;state.players[2].cause='白狼王带走';state.players[2].deathRound='第1天';state.players[6].note='解药已用';renderAll();});await frames(p);
   const m=await p.evaluate(()=>{const grid=$('grid'),bottom=document.querySelector('.bottombar').getBoundingClientRect();return {fit:document.body.classList.contains('home-fit'),scroll:document.documentElement.scrollHeight>innerHeight+1,bottom:grid.getBoundingClientRect().bottom,footer:bottom.top,bad:[...grid.children].filter(t=>[...t.querySelectorAll('.avatar,.pname,.pstatus,.rolebadge,.pnote')].some(e=>e.getBoundingClientRect().bottom>t.getBoundingClientRect().bottom-1)).length};});if(!m.fit||m.scroll||m.bottom>m.footer||m.bad)issues.push({width,height,...m});
  }
  for(const [width,height] of [[320,568],[360,640],[393,740],[640,360],[800,480]]){
   await p.setViewportSize({width,height});await p.evaluate(()=>{returnToGame();state.players.forEach(p=>p.alive=true);state.sheriffId=1;state.gameId='layout-'+Math.random();renderAll();openVoting();});await frames(p);
   const m=await p.evaluate(()=>{const g=$('voteTargets'),r=g.getBoundingClientRect(),bad=[];for(const t of g.children){const b=t.getBoundingClientRect();for(const e of t.querySelectorAll('.avatar,.rolebadge,.tile-name,.tile-state')){const q=e.getBoundingClientRect();if(q.top<b.top+1||q.bottom>b.bottom-1||q.left<b.left+1||q.right>b.right-1)bad.push(t.dataset.target+':'+e.className);}}return {scroll:document.documentElement.scrollHeight>innerHeight+1,bad,height:r.height};});if(m.scroll||m.bad.length)issues.push({width,height,page:'sheriffVoting',...m});
  }
  fs.writeFileSync(path.join(work,'v120-layout-report.json'),JSON.stringify(issues,null,2));
  await p.setViewportSize({width:393,height:800});await p.evaluate(()=>{returnToGame();renderAll();});await frames(p);await p.screenshot({path:path.join(work,'v120-home-qa.png')});await p.locator('#btnVote').click();await frames(p);await p.screenshot({path:path.join(work,'v120-sheriff-qa.png')});await context.close();assert.deepEqual(issues,[]);
 });
 assert.deepEqual(errors,[]);fs.writeFileSync(path.join(root,'tests/v120-regression-report.json'),JSON.stringify({version:'1.3.0',passed:checks,scriptErrors:errors,deviceTested:false},null,2));console.log('All '+checks.length+' groups passed.');await browser.close();
})().catch(async e=>{console.error(e);if(browser)await browser.close();process.exit(1);});
