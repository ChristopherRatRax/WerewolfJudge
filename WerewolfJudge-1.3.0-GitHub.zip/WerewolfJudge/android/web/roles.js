/* 基础角色规则：黑狼王即狼王；隐狼采用接刀版。所有技能仍由法官记录，不自动推进昼夜。
   参考：https://langrensha.com/wanfa/guize/2017/10/18/26899_719311.html
   骑士决斗会封锁被决斗狼人的出局技能，殉情不能触发开枪。
   警长是附加身份，投票历史单独保存当时的警长与票权。 */
const WOLF_ROLES=new Set(['狼人','白狼王','黑狼王','隐狼','狼美人']);
const ROLE_RULES={
  白狼王:'白天自爆时可带走一名其他存活玩家，非自爆出局不能发动。记录后由法官按「前进」入夜。',
  黑狼王:'又称狼王。被狼刀、放逐或开枪带走后可发动一次开枪；被毒、殉情、自爆、被骑士决斗时不能发动。',
  骑士:'白天放逐发言阶段可翻牌决斗一次。对方为狼人（包括隐狼）则对方出局，且不能发动出局技能；对方为好人则骑士出局。决斗狼人后由法官按「前进」入夜。',
  隐狼:'接刀版：属于狼人阵营，预言家查验为好人，不能自爆。知道其他狼人，其他狼人不知道隐狼；其余狼人存活时不参与狼刀，全部出局后获得刀权。',
  狼美人:'夜间可魅惑一名其他存活玩家，不能连续两晚选择同一人，不能自刀、自爆。出局时有效魅惑对象随之殉情且不能发动出局技能；被骑士决斗时不触发殉情。'
};
Object.assign(CAUSE_EMOJI,{'自爆':'💥','白狼王带走':'💥','黑狼王枪杀':'🔫','决斗':'⚔️','决斗失败':'⚔️','殉情':'💘','死亡':'💀'});
function isWolfRole(p){return WOLF_ROLES.has(p?.role);}
function normalizeRoleState(){
  state.sheriffId=state.players.some(p=>p.id===state.sheriffId)?state.sheriffId:null;
  state.players.forEach(p=>{if(p.role==='狼王')p.role='黑狼王';});
}
function sheriffMark(p,sheriffId=state.sheriffId){return p.id===sheriffId?'<span class="sheriff-mark" aria-label="警长">★</span>':'';}
function skillMark(p){
  let text='';
  if(p.role==='骑士'&&p.knightUsed)text='⚔✓';
  if(p.role==='黑狼王'&&p.wolfShotUsed)text='🔫✓';
  if(p.role==='狼美人'&&p.charms?.[state.round])text='💘'+p.charms[state.round];
  if(p.role==='隐狼'&&p.alive&&!state.players.some(x=>x.alive&&x.id!==p.id&&isWolfRole(x)))text='🔪';
  return text?`<span class="skill-mark">${text}</span>`:'';
}
function canWolfKingShoot(p){return p.role==='黑狼王'&&!p.alive&&!p.wolfShotUsed&&['狼刀','放逐','枪杀','黑狼王枪杀','白狼王带走'].includes(p.cause);}
function renderRoleControls(p){
  let actions='';const alive=p.alive,night=state.phase==='night';
  if(p.role==='白狼王'&&alive&&!night)actions+=`<button class="btn red" onclick="chooseRoleTarget('blast',${p.id})">💥 自爆带人</button>`;
  if(canWolfKingShoot(p))actions+=`<button class="btn orange" onclick="chooseRoleTarget('wolfShot',${p.id})">🔫 黑狼王开枪</button>`;
  if(p.role==='骑士'&&alive&&!night&&!p.knightUsed)actions+=`<button class="btn blue" onclick="chooseRoleTarget('duel',${p.id})">⚔️ 发动决斗</button>`;
  if(p.role==='狼美人'&&alive&&night){
    actions+=`<button class="btn purple" onclick="chooseRoleTarget('charm',${p.id})">💘 ${p.charms?.[state.round]?'修改':'选择'}魅惑对象</button>`;
    if(p.charms?.[state.round])actions+=`<button class="btn ghost" onclick="cancelTonightCharm(${p.id})">取消今夜魅惑</button>`;
  }
  const sheriff=p.id===state.sheriffId;
  const badge=sheriff?`<span class="sheriff-label">★ 警长${p.alive?'':' · 待移交'}</span><button class="btn ghost small" onclick="removeSheriff()">撕毁警徽</button>`:alive&&!isRevealedIdiot(p)?`<button class="btn yellow small" onclick="assignSheriff(${p.id})">${state.sheriffId?'★ 移交警徽给此人':'★ 设为警长'}</button>`:'';
  const status=p.role==='骑士'&&p.knightUsed?'⚔️ 决斗已使用':p.role==='黑狼王'&&p.wolfShotUsed?'🔫 开枪已使用':p.role==='狼美人'&&p.charms?.[state.round]?'💘 今夜魅惑：'+p.charms[state.round]+'号':p.role==='隐狼'&&alive?(state.players.some(x=>x.id!==p.id&&x.alive&&isWolfRole(x))?'🌘 尚未接刀':'🔪 其余狼人已出局 · 可接刀'):'';
  return `<div class="role-tools">${badge?`<div class="sheriff-actions">${badge}${sheriff?'<span class="tool-caption">移交：点接任玩家 → 移交警徽</span>':''}</div>`:''}${actions?`<div class="role-skill-actions">${actions}</div>`:''}${status?`<div class="tool-caption">${status}</div>`:''}${ROLE_RULES[p.role]?`<details class="role-rules"><summary>${ROLE_META[p.role].emoji} ${p.role}规则</summary><p>${ROLE_RULES[p.role]}</p></details>`:''}</div>`;
}
function assignSheriff(pid){
  const p=state.players.find(p=>p.id===pid);if(!p||!canVote(p)||state.sheriffId===pid)return;
  const old=state.players.find(p=>p.id===state.sheriffId);
  const apply=()=>{snapshot();state.sheriffId=pid;addLog('警长',p,old?`★ ${pLabel(old)} 将警徽移交给 ${pLabel(p)}`:`★ ${pLabel(p)} 成为警长`);save();renderAll();openSheet(pid);toast('警长标记已更新');};
  if(old)showConfirm('移交警徽？',`${pLabel(old)} → ${pLabel(p)}，原警长标记将移除。`,apply);else apply();
}
function removeSheriff(){const p=state.players.find(p=>p.id===state.sheriffId);if(!p)return;showConfirm('撕毁警徽？','本局将暂时没有警长，已保存投票不受影响。',()=>{snapshot();state.sheriffId=null;addLog('警长',p,`★ ${pLabel(p)} 撕毁警徽`);save();renderAll();openSheet(p.id);});}
function resetChangedRole(p,old){
  delete p.knightUsed;delete p.wolfShotUsed;delete p.whiteBlastUsed;
  if(old==='狼美人')delete p.charms;
  syncCharmConsequences();
}
function roleSkillError(type,p,target=null){
  if(!p)return '未找到技能发动者';
  if(type==='blast'&&(p.role!=='白狼王'||!p.alive||state.phase!=='day'))return '白狼王只能在存活的白天自爆';
  if(type==='wolfShot'&&!canWolfKingShoot(p))return '该死因不能开枪，或开枪已经使用';
  if(type==='duel'&&(p.role!=='骑士'||!p.alive||state.phase!=='day'||p.knightUsed))return '骑士仅能在白天发言阶段决斗一次';
  if(type==='charm'&&(p.role!=='狼美人'||!p.alive||state.phase!=='night'))return '狼美人只能在存活的夜晚记录魅惑';
  if(!['blast','wolfShot','duel','charm'].includes(type))return '无效技能';
  if(target){
    if(!target.alive||target.id===p.id)return '请选择其他存活玩家';
    if(type==='charm'&&p.charms?.[state.round-1]===target.id)return '不能连续两晚魅惑同一位玩家';
  }
  return '';
}
function chooseRoleTarget(type,pid){
  const p=state.players.find(p=>p.id===pid),error=roleSkillError(type,p);if(error){toast(error);return;}
  closeSheet();ui.roleAction={type,actor:pid};
  $('roleTargetTitle').textContent=({blast:'💥 白狼王自爆带谁',wolfShot:'🔫 黑狼王开枪带谁',duel:'⚔️ 骑士决斗谁',charm:'💘 狼美人魅惑谁'})[type];
  $('roleTargetCaption').textContent=pLabel(p)+' · '+(type==='charm'?'选择一位，不能连续两晚重复':'选择后确认，关联变化可一次撤销');
  $('roleTargetGrid').innerHTML=state.players.map(t=>{const forbidden=roleSkillError(type,p,t),prior=type==='charm'&&p.charms?.[state.round-1]===t.id;return `<button class="vote-tile ${forbidden?'inactive':''}" data-role-target="${t.id}" ${forbidden?'disabled':''}><span class="avatar" style="background:${participantColor(t)}">${t.id}${sheriffMark(t)}</span><span class="tile-info">${roleBadge(t)}<span class="tile-state">${prior?'昨夜已选':t.id===pid?'本人':t.alive?'存活':'已出局'}</span></span></button>`;}).join('');
  $('roleTargetOverlay').classList.add('show');$('roleTargetSheet').classList.add('show');
}
function closeRoleTarget(){$('roleTargetOverlay').classList.remove('show');$('roleTargetSheet').classList.remove('show');ui.roleAction=null;}
$('roleTargetGrid').addEventListener('click',e=>{const el=e.target.closest('[data-role-target]');if(!el||el.disabled||!ui.roleAction)return;const a={...ui.roleAction},p=state.players.find(p=>p.id===a.actor),t=state.players.find(p=>p.id===Number(el.dataset.roleTarget));if(!p||!t)return;const error=roleSkillError(a.type,p,t);if(error){toast(error);return;}
  if(a.type==='charm'){executeRoleSkill(a.type,p.id,t.id);return;}
  const message=a.type==='blast'?`${pLabel(p)} 自爆，并带走 ${pLabel(t)}。`:a.type==='wolfShot'?`${pLabel(p)} 开枪带走 ${pLabel(t)}。`:isWolfRole(t)?`${pLabel(t)} 属于狼人阵营，将决斗出局且不能发动出局技能。`:`${pLabel(t)} 属于好人阵营，${pLabel(p)} 将决斗失败出局，对方存活。`;
  showConfirm('确认发动技能？',message,()=>executeRoleSkill(a.type,p.id,t.id));
});
function markRoleDeath(p,cause,when=roundLabel()){p.alive=false;p.cause=cause;p.deathRound=when;delete p.charmLink;delete p.godOverride;}
function executeRoleSkill(type,pid,tid){
  const p=state.players.find(x=>x.id===pid),t=state.players.find(x=>x.id===tid),error=roleSkillError(type,p,t);if(error||!t){toast(error||'目标不存在');return;}
  snapshot();let detail='';
  if(type==='blast'){markRoleDeath(p,'自爆');markRoleDeath(t,'白狼王带走');p.whiteBlastUsed=true;detail=`💥 ${roundLabel()}，白狼王 ${pLabel(p)} 自爆，带走 ${pLabel(t)}；应进入黑夜`;}
  if(type==='wolfShot'){markRoleDeath(t,'黑狼王枪杀');p.wolfShotUsed=true;detail=`🔫 ${roundLabel()}，黑狼王 ${pLabel(p)} 开枪带走 ${pLabel(t)}`;}
  if(type==='duel'){p.knightUsed=true;const hit=isWolfRole(t);markRoleDeath(hit?t:p,hit?'决斗':'决斗失败');detail=`⚔️ ${roundLabel()}，骑士 ${pLabel(p)} 决斗 ${pLabel(t)}：${hit?'狼人出局且不能发动技能；应进入黑夜':'好人存活，骑士决斗失败出局；继续白天发言'}`;}
  if(type==='charm'){delete t.godOverride;p.charms=p.charms||{};p.charms[state.round]=t.id;detail=`💘 ${roundLabel()}，狼美人 ${pLabel(p)} 魅惑 ${pLabel(t)}`;}
  addLog('技能',t,detail);Object.assign(state.logs[state.logs.length-1],{actorId:p.id});
  syncCharmConsequences();closeRoleTarget();save();renderAll();toast(type==='blast'||type==='duel'&&isWolfRole(t)?'技能已记录，按「前进」进入黑夜':'技能已记录');
}
function cancelTonightCharm(pid){const p=state.players.find(x=>x.id===pid);if(!p||roleSkillError('charm',p)||!p.charms?.[state.round])return;snapshot();delete p.charms[state.round];addLog('技能',p,`💘 ${roundLabel()}，法官取消 ${pLabel(p)} 的今夜魅惑`);syncCharmConsequences();save();renderAll();openSheet(pid);}
function restoreLinkedCharm(p){const link=p.charmLink;if(!link)return;if(!p.alive&&p.cause==='殉情')Object.assign(p,link.before);delete p.charmLink;}
function restoreNightCharmDeaths(){state.players.forEach(p=>{if(p.charmLink?.round===state.round&&p.charmLink?.phase==='night')restoreLinkedCharm(p);});}
function canTriggerCharm(p){return p?.role==='狼美人'&&!p.alive&&['狼刀','毒药','狼刀+毒药','枪杀','放逐','黑狼王枪杀','白狼王带走'].includes(p.cause);}
function syncCharmConsequences(){
  state.players.forEach(p=>{const link=p.charmLink;if(!link)return;const source=state.players.find(x=>x.id===link.source);const valid=canTriggerCharm(source)&&source.charms?.[link.round]===p.id&&source.deathRound===link.when;if(!valid)restoreLinkedCharm(p);else if(p.cause!=='殉情')delete p.charmLink;});
  state.players.filter(p=>canTriggerCharm(p)&&[roundLabel(state.round,'night'),roundLabel(state.round,'day')].includes(p.deathRound)).forEach(source=>{
    const t=state.players.find(p=>p.id===source.charms?.[state.round]);if(!t||!t.alive||t.id===source.id||t.godOverride?.alive&&t.godOverride.round===state.round)return;
    const before={alive:t.alive,cause:t.cause,deathRound:t.deathRound};t.alive=false;t.cause='殉情';t.deathRound=source.deathRound;t.charmLink={source:source.id,round:state.round,phase:source.deathRound===roundLabel(state.round,'night')?'night':'day',when:source.deathRound,before};
    const detail=`💘 ${source.deathRound}，${pLabel(t)} 因狼美人 ${pLabel(source)} 出局而殉情，不能发动出局技能`;
    if(!state.logs.some(l=>l.charmEvent===source.id+'-'+state.round+'-'+t.id)){addLog('技能',t,detail);Object.assign(state.logs[state.logs.length-1],{actorId:source.id,charmEvent:source.id+'-'+state.round+'-'+t.id});}
  });
}

/* 法官强制修正：只改当前玩家，不触发角色出局技能，也不重置技能/药水。
   清除当前夜对该玩家的旧伤害槽，避免其他行动重算时覆盖神的操作；新行动仍可造成死亡。 */
function requestGodLife(pid,alive){
  const p=state.players.find(x=>x.id===pid);if(!p)return;
  snapshot();
  const rec=state.nights[state.round];
  if(rec){if(rec.knife===pid)rec.knife=null;if(rec.poison===pid)rec.poison=null;if(rec.deaths)delete rec.deaths[pid];}
  state.players.forEach(t=>{if(t.id===pid||t.charmLink?.source===pid)delete t.charmLink;});
  p.alive=alive;p.cause=alive?null:'死亡';p.deathRound=alive?null:roundLabel();p.godOverride={alive,round:state.round};
  const action=alive?'复活':'死亡';
  addLog(action,p,`${alive?'♻️':'💀'} ${roundLabel()}，${pLabel(p)} 已${action}`);
  save();renderAll();closeSheet();toast(`${pLabel(p)} 已${action}`);
}

/* 用可用高度适配主页，窄小屏保留可读大小，允许必要滚动而不裁切信息。 */
function fitHomeGrid(){
  const grid=$('grid'),main=document.querySelector('main');document.body.classList.remove('home-fit');
  if(!state.started||ui.page||!state.players.length)return;
  const width=grid.getBoundingClientRect().width,cols=window.innerWidth>=1024?5:window.innerWidth>=720?4:3,rows=Math.ceil(state.players.length/cols);
  const bottom=document.querySelector('.bottombar').getBoundingClientRect().height;
  document.documentElement.style.setProperty('--bottom-height',bottom+'px');
  const height=window.innerHeight-grid.getBoundingClientRect().top-bottom-14;
  const gap=10,ch=(height-gap*(rows-1))/rows;
  if(ch<112)return;
  document.body.classList.add('home-fit');grid.style.setProperty('--home-cols',cols);grid.style.setProperty('--home-rows',rows);grid.style.setProperty('--home-height',height+'px');grid.style.setProperty('--home-avatar',Math.min(58,Math.max(34,Math.floor(ch-80)))+'px');
}
