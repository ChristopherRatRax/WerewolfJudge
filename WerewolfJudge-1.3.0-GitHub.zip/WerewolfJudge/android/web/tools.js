/* 独立工具数据不进入原对局撤销栈，避免撤销死亡时丢失投票历史。 */
const TOOLS_KEY='ww-judge-tools-v2';
const clone=x=>JSON.parse(JSON.stringify(x));
const originalTimerDefaults=()=>({mode:'down',duration:90000,elapsed:0,anchor:0,status:'idle',token:'',notified:false,color:true,sound:true,vibrate:true,countdownSound:true,warning:10,upTarget:false,presets:[{id:'60',name:'1分钟',seconds:60},{id:'90',name:'1分30秒',seconds:90},{id:'120',name:'2分钟',seconds:120}]});
let extra=(()=>{try{return JSON.parse(localStorage.getItem(TOOLS_KEY))||{};}catch(e){return {};}})();
extra.games=extra.games||{};extra.timer={...originalTimerDefaults(),...extra.timer};
if(!Array.isArray(extra.timer.presets)) extra.timer.presets=originalTimerDefaults().presets;
const ui={page:'',draftKey:'',reviewId:null,resultId:null,numberPid:null,numberOrigin:'game',presetId:null};
let voteFrame=0,numberControlsTimer=0,audioContext=null,toolStorageFailed=false,keepAwakeHandle=null;
let reminderRequest=null,nativeCountdownScheduled=false;
const webReminderChannels=new Set();
function persistTools(){try{localStorage.setItem(TOOLS_KEY,JSON.stringify(extra));}catch(e){if(!toolStorageFailed){toolStorageFailed=true;toast('存储空间不足，请先复制重要记录');}}}
function ensureGameIdentity(){if(state.started&&!state.gameId){state.gameId='legacy-'+Date.now().toString(36);save();}}
function gameTools(){ensureGameIdentity();const id=state.gameId||'unstarted';if(!extra.games[id])extra.games[id]={drafts:{},polls:[],seq:1};const g=extra.games[id];g.drafts=g.drafts||{};g.polls=g.polls||[];g.seq=g.seq||1;return g;}
function participantColor(p){return AVATAR_COLORS[(p.id-1)%AVATAR_COLORS.length];}
function canVote(p){return !!p.alive&&!isRevealedIdiot(p);}
function playerName(p){return p.id+'号';}
function tileName(p){return p.id+'号';}
function roleBadge(p){const r=ROLE_META[p.role]||ROLE_META['平民'];return `<span class="rolebadge" style="background:${r.color}">${r.emoji} ${esc(p.role)}</span>`;}
function closeToolSheets(){closeRoleTarget();closeSheet();closeSetup();closeLog();closeTimer();closePresetEditor();closePollDetail();}
function showTool(page){
  closeToolSheets();ui.page=page;$('toolHost').hidden=false;document.body.classList.add('tools-open');
  const map={vote:'votePage',result:'voteResultPage',numbers:'numberPickerPage',settlement:'settlementPage'};
  Object.values(map).forEach(id=>$(id).hidden=id!==map[page]);
  updateViewport();requestAnimationFrame(fitVisibleGrid);
}
function returnToGame(){hideNumberScreen();closeToolSheets();ui.page='';$('toolHost').hidden=true;document.body.classList.remove('tools-open','vote-tight');renderAll();}
function renderToolChrome(){
  document.body.classList.toggle('started',!!state.started);
  ['btnVote','btnNumbers','btnTimer'].forEach(id=>$(id).hidden=!state.started);
  document.querySelectorAll('[data-game-back]').forEach(b=>b.hidden=!state.started);
  $('btnEndGame').disabled=!state.started;$('btnViewSettlement').disabled=!state.started;
  $('btnTimer').classList.toggle('running',extra.timer.status==='running');$('btnTimer').classList.toggle('timer-done',extra.timer.status==='done');
  if(state.started)ensureGameIdentity();else if(ui.page)returnToGame();
  updateViewport();
}
function updateViewport(){
  const h=document.querySelector('header').getBoundingClientRect().height;
  document.documentElement.style.setProperty('--header-height',h+'px');
  document.body.classList.toggle('vote-tight',!!ui.page&&window.innerHeight<770);
  cancelAnimationFrame(voteFrame);voteFrame=requestAnimationFrame(()=>{fitVisibleGrid();fitHomeGrid();});
}
function fitVisibleGrid(){
  const grid=ui.page==='vote'?$('voteTargets'):ui.page==='result'?$('voteResultGrid'):ui.page==='numbers'?$('numberPickerGrid'):null;
  if(!grid||grid.hidden)return;const n=grid.children.length;if(!n)return;
  const {width:w,height:h}=grid.getBoundingClientRect();if(w<=0||h<=0)return;
  const gap=window.innerHeight<770?5:7;let best=null;
  const maxCols=Math.min(8,Math.max(2,Math.floor((w+gap)/72)));
  const minCols=Math.min(n,window.innerWidth>=600?3:Math.min(3,maxCols));
  for(let c=Math.max(1,minCols);c<=Math.min(maxCols,n);c++){
    const rows=Math.ceil(n/c),cw=(w-gap*(c-1))/c,ch=(h-gap*(rows-1))/rows;
    const vertical=Math.min(58,cw-18,ch-(ui.page==='result'?62:57));
    const horizontal=Math.min(40,ch-12,cw-45);
    const row=vertical<26&&horizontal>=18,avatar=row?horizontal:vertical;
    const requiredHeight=ui.page==='result'?44:47;
    const score=avatar-(c===3?0:.2*c)-(row&&ch<requiredHeight?(requiredHeight-ch)*12:0);
    if(!best||score>best.score)best={c,rows,avatar,row,ch,score};
  }
  if(!best)return;grid.style.setProperty('--grid-cols',best.c);grid.style.setProperty('--grid-rows',best.rows);
  grid.style.setProperty('--tile-avatar',Math.max(17,Math.floor(best.avatar))+'px');
  grid.classList.toggle('tile-row',best.row);grid.classList.toggle('tiny-grid',best.ch<65);
}
function animateVoter(direction){const el=$('voterFocus');if(!el.animate||matchMedia('(prefers-reduced-motion:reduce)').matches)return;el.animate([{opacity:.5,transform:`translateX(${direction<0?-12:12}px)`},{opacity:1,transform:'translateX(0)'}],{duration:180,easing:'cubic-bezier(.2,.7,.25,1)'});}

/* ================= 按人记录投票 ================= */
function voteDraftKey(){return state.round+'-'+state.phase;}
function createVoteDraft(){return {round:state.round,phase:state.phase,ballots:{},selected:null,savedId:null,roster:null,undo:[],weightVersion:1,sheriffWeight:gameTools().sheriffWeight||1.5};}
function currentDraft(){return gameTools().drafts[ui.draftKey];}
function draftRoster(d){return d.roster||state.players;}
function normalizeBallots(d){
  const roster=draftRoster(d),eligible=roster.filter(canVote),ids=new Set(eligible.map(p=>p.id));
  const normalized={};eligible.forEach(p=>{const b=d.ballots[p.id];if(!b)return;const valid=values=>[...new Set(Array.isArray(values)?values:[])].filter(id=>ids.has(id)&&id!==p.id).sort((a,b)=>a-b);normalized[p.id]={targets:valid(b.targets),abstain:!!b.abstain};if(normalized[p.id].abstain){normalized[p.id].targets=[];if(Array.isArray(b.beforeAbstain))normalized[p.id].beforeAbstain=valid(b.beforeAbstain);}});d.ballots=normalized;
  if(!ids.has(d.selected))d.selected=eligible[0]?.id??null;
  return {roster,eligible};
}
function openVoting(){
  if(!state.started){toast('请先开局');return;}ui.reviewId=null;ui.draftKey=voteDraftKey();
  const g=gameTools();if(!g.drafts[ui.draftKey])g.drafts[ui.draftKey]=createVoteDraft();
  const d=currentDraft();if(d.savedId){showVoteResult(d.savedId);return;}
  normalizeBallots(d);showTool('vote');renderVoting();persistTools();
}
function voteViewContext(){
  if(ui.reviewId){const p=gameTools().polls.find(x=>x.id===ui.reviewId);return p?{draft:p,roster:p.roster,eligible:p.roster.filter(canVote),readonly:true}:null;}
  const d=currentDraft();if(!d)return null;const c=normalizeBallots(d);return {draft:d,...c,readonly:false};
}
function renderVoting(){
  const c=voteViewContext();if(!c)return returnToGame();const {draft:d,roster,eligible,readonly}=c;
  let selected=readonly?ui.reviewVoter:d.selected;if(!eligible.some(p=>p.id===selected))selected=eligible[0]?.id??null;
  if(readonly)ui.reviewVoter=selected;else d.selected=selected;
  const p=roster.find(x=>x.id===selected),b=d.ballots[selected]||{targets:[],abstain:false},index=eligible.findIndex(x=>x.id===selected);
  $('voteTitle').textContent=readonly?'逐人投票明细':'🗳️ 投票记录';
  $('voteRound').textContent=roundLabel(d.round,d.phase)+' · '+(d.number?'第'+d.number+'轮':d.savedId?'修改已保存记录':'多选不限制人数');
  $('voterPosition').textContent=p?`${index+1}/${eligible.length}`:'0/0';
  const rules=voteRules(d);
  $('voterAvatar').innerHTML=p?p.id+sheriffMark(p,rules.sheriffId):'—';$('voterAvatar').style.background=p?participantColor(p):'#a8afb8';
  $('voterFocus').setAttribute('aria-label',p?'当前投票人'+playerName(p):'没有可投票的玩家');$('voterRole').innerHTML=p?roleBadge(p):'';
  $('sheriffWeight').hidden=!p||p.id!==rules.sheriffId;
  [1.5,2].forEach(v=>{const button=$(v===1.5?'weight15':'weight2');button.className='btn '+(rules.weight===v?'yellow':'ghost');button.setAttribute('aria-pressed',String(rules.weight===v));button.disabled=readonly;});
  const direction=p?`投向：${b.abstain?'弃票':b.targets.length?b.targets.map(id=>id+'号').join('、'):'尚未记录'}`:'出局及已翻牌白痴不参与投票';
  $('voteDirection').textContent=direction;$('voteDirection').title=direction;
  $('votePrev').disabled=index<=0;$('voteNext').disabled=index<0||index>=eligible.length-1;
  $('voteAbstain').hidden=readonly;$('voteAbstain').disabled=!p;$('voteAbstain').textContent=b.abstain?'取消弃票':'记录弃票';$('voteAbstain').setAttribute('aria-pressed',String(b.abstain));
  const recorded=eligible.filter(x=>{const v=d.ballots[x.id];return v&&(v.abstain||v.targets.length>0);}).length;
  $('voteProgress').textContent=`${readonly?'查看投向':'选择投给谁'} · 已记录 ${recorded}/${eligible.length}`;
  $('voteTargets').innerHTML=roster.map(t=>{
    const self=t.id===selected,allowed=canVote(t),chosen=b.targets.includes(t.id),disabled=readonly||!p||self||!allowed;
    const status=!t.alive?'已出局':isRevealedIdiot(t)?'已翻牌':self?'本人':'存活';
    return `<button class="vote-tile ${!allowed?'inactive':''} ${self?'self':''} ${chosen?'selected':''}" data-target="${t.id}" aria-pressed="${chosen}" aria-label="${esc(playerName(t))}，${esc(t.role)}，${status}${chosen?'，已选择':''}" ${disabled?'disabled':''}>
      ${chosen?'<span class="tile-check">✓</span>':''}<span class="avatar" style="background:${participantColor(t)}">${t.id}${sheriffMark(t,rules.sheriffId)}</span><span class="tile-info">${roleBadge(t)}<span class="tile-state">${status}</span></span></button>`;
  }).join('');
  $('voteEditFooter').hidden=readonly;$('voteReviewFooter').hidden=!readonly;$('voteUndo').disabled=readonly||!d.undo?.length;
  fitVisibleGrid();
}
function rememberBallotEdit(d){d.undo=d.undo||[];const snapshot={ballots:clone(d.ballots),selected:d.selected,savedId:d.savedId,roster:d.roster?clone(d.roster):null,round:d.round,phase:d.phase,sheriffId:d.sheriffId??null,sheriffWeight:d.sheriffWeight??1.5,weightVersion:d.weightVersion??0};d.undo.push(snapshot);if(d.undo.length>80)d.undo.shift();}
function toggleVoteTarget(id){
  if(ui.reviewId)return;const d=currentDraft();if(!d)return;const {roster}=normalizeBallots(d),voter=roster.find(p=>p.id===d.selected),target=roster.find(p=>p.id===id);
  if(!voter||!target||!canVote(voter)||!canVote(target)||id===d.selected)return;
  rememberBallotEdit(d);const b=d.ballots[d.selected]||{targets:[],abstain:false};b.abstain=false;delete b.beforeAbstain;
  b.targets=b.targets.includes(id)?b.targets.filter(x=>x!==id):b.targets.concat(id).sort((a,b)=>a-b);d.ballots[d.selected]=b;
  persistTools();renderVoting();
}
$('voteTargets').addEventListener('click',e=>{const b=e.target.closest('[data-target]');if(b&&!b.disabled)toggleVoteTarget(Number(b.dataset.target));});
function recordAbstention(){
  if(ui.reviewId)return;const d=currentDraft();if(!d||d.selected==null)return;
  normalizeBallots(d);const voter=draftRoster(d).find(p=>p.id===d.selected);if(!voter||!canVote(voter))return;
  const b=d.ballots[d.selected]||{targets:[],abstain:false};rememberBallotEdit(d);
  if(b.abstain){
    const restored=Array.isArray(b.beforeAbstain)?b.beforeAbstain.slice():[];
    if(restored.length)d.ballots[d.selected]={targets:restored,abstain:false};else delete d.ballots[d.selected];
  }else d.ballots[d.selected]={targets:[],abstain:true,beforeAbstain:b.targets.slice()};
  persistTools();renderVoting();
}
function moveVoter(direction){const c=voteViewContext();if(!c)return;const current=c.readonly?ui.reviewVoter:c.draft.selected,index=c.eligible.findIndex(p=>p.id===current),next=c.eligible[index+direction];if(!next)return;if(c.readonly)ui.reviewVoter=next.id;else c.draft.selected=next.id;persistTools();renderVoting();animateVoter(direction);}
function undoBallotEdit(){if(ui.reviewId)return;const d=currentDraft();if(!d?.undo?.length)return;const oldWeight=d.sheriffWeight,previous=d.undo.pop();Object.assign(d,previous);if(oldWeight!==d.sheriffWeight&&[1.5,2].includes(d.sheriffWeight))gameTools().sheriffWeight=d.sheriffWeight;persistTools();renderVoting();toast('已撤销本轮投票操作');}
function confirmClearVotes(){
  if(ui.reviewId)return;showConfirm('清空本轮所有投票？','将清空当前所有玩家的投票对象及弃票标记。\n已保存的历史记录会保留。',()=>{
    const d=currentDraft();if(!d)return;rememberBallotEdit(d);d.ballots={};d.savedId=null;d.roster=null;d.round=state.round;d.phase=state.phase;d.selected=null;d.sheriffId=null;d.weightVersion=1;
    normalizeBallots(d);persistTools();renderVoting();toast('已清空当前投票表，历史记录保留');
  });
}
function voteRules(d){return {sheriffId:d.roster?(d.sheriffId??null):(state.sheriffId??null),weight:[1.5,2].includes(d.sheriffWeight)?d.sheriffWeight:1.5};}
function setSheriffWeight(value){
  if(ui.reviewId||![1.5,2].includes(value))return;const d=currentDraft();if(!d)return;const rules=voteRules(d);
  if(d.selected!==rules.sheriffId||rules.weight===value)return;
  rememberBallotEdit(d);d.sheriffWeight=value;gameTools().sheriffWeight=value;persistTools();renderVoting();toast('警长每个所选目标计 '+value+' 票');
}
function pollVoteWeight(poll,id){return poll.weightVersion===1&&[1,1.5,2].includes(poll.weights?.[id])?poll.weights[id]:1;}
function tallyVotes(poll){
  const eligible=poll.roster.filter(canVote),ids=new Set(eligible.map(p=>p.id)),incoming=Object.fromEntries(poll.roster.map(p=>[p.id,[]])),units=Object.fromEntries(poll.roster.map(p=>[p.id,0]));
  eligible.forEach(v=>{const b=poll.ballots[v.id];if(!b||b.abstain)return;[...new Set(b.targets||[])].filter(id=>id!==v.id&&ids.has(id)).forEach(id=>{incoming[id].push(v.id);units[id]+=Math.round(pollVoteWeight(poll,v.id)*2);});});
  const totals=Object.fromEntries(Object.entries(units).map(([id,n])=>[id,n/2]));
  const max=Math.max(0,...eligible.map(p=>totals[p.id])),leaders=max?eligible.filter(p=>totals[p.id]===max).map(p=>p.id):[];
  return {incoming,totals,max,leaders,tied:leaders.length>1,recorded:eligible.filter(p=>{const b=poll.ballots[p.id];return b&&(b.abstain||b.targets?.length);}).length,voters:eligible.length};
}
function saveVoteRound(){
  if(ui.reviewId)return;const d=currentDraft();if(!d)return;normalizeBallots(d);const g=gameTools(),old=g.polls.find(p=>p.id===d.savedId);
  const poll={id:old?.id||state.gameId+'-poll-'+g.seq++,number:old?.number||g.polls.filter(p=>p.round===d.round&&p.phase===d.phase).length+1,round:d.round,phase:d.phase,roster:clone(draftRoster(d)),ballots:clone(d.ballots),savedAt:old?.savedAt||Date.now(),updatedAt:Date.now()};
  const rules=voteRules(d);poll.sheriffId=rules.sheriffId;poll.sheriffWeight=rules.weight;poll.weightVersion=1;poll.weights=Object.fromEntries(poll.roster.map(p=>[p.id,p.id===rules.sheriffId?rules.weight:1]));
  if(old)g.polls[g.polls.indexOf(old)]=poll;else g.polls.push(poll);d.savedId=poll.id;d.roster=clone(poll.roster);d.sheriffId=poll.sheriffId;d.sheriffWeight=poll.sheriffWeight;d.weightVersion=1;d.undo=[];
  if(d.round===state.round&&d.phase===state.phase)g.drafts[voteDraftKey()]=d;
  const t=tallyVotes(poll),text=`🗳️ ${roundLabel(poll.round,poll.phase)} 第${poll.number}轮投票：${t.max?t.leaders.map(id=>id+'号').join('、')+(t.tied?'平票':'最高票')+'（'+t.max+'票）':'尚无有效选票'}；已记录 ${t.recorded}/${t.voters}`;
  const log=state.logs.find(l=>l.pollId===poll.id);if(log)log.detail=text;else{addLog('投票',null,text);Object.assign(state.logs[state.logs.length-1],{pollId:poll.id,round:poll.round,phase:poll.phase});}
  save();persistTools();showVoteResult(poll.id);toast(old?'本轮投票已更新':'投票已保存并结算');
}
function showVoteResult(id){
  const poll=gameTools().polls.find(p=>p.id===id);if(!poll){toast('未找到该轮投票');return;}ui.resultId=id;ui.reviewId=null;
  const t=tallyVotes(poll);showTool('result');$('voteResultRound').textContent=roundLabel(poll.round,poll.phase)+` · 第${poll.number}轮 · 已保存`;
  $('voteResultBanner').classList.toggle('tied',t.tied);$('voteResultBanner').textContent=t.max?`${t.tied?'⚠️ 最高票平票：':'最高票：'}${t.leaders.map(id=>id+'号').join('、')} · ${t.tied?'各':''}${t.max}票`:'本轮尚无有效选票';
  $('voteResultBanner').classList.toggle('highest',t.max>0);
  $('voteResultGrid').innerHTML=poll.roster.map(p=>{const incoming=t.incoming[p.id]||[],highest=t.leaders.includes(p.id),tied=t.tied&&highest;return `<button class="vote-tile ${!canVote(p)?'inactive':''} ${highest?'highest':''} ${tied?'tied':''}" onclick="showPollIncoming('${poll.id}',${p.id})" aria-label="${esc(playerName(p))}，${t.totals[p.id]}票${highest?'，最高票':''}${tied?'，平票':''}，查看投票来源"><span class="avatar" style="background:${participantColor(p)}">${p.id}${sheriffMark(p,poll.sheriffId)}</span><span class="tile-info"><span class="vote-total">${t.totals[p.id]}票</span><span class="vote-result-source">${tied?'⚠️ 平票':!p.alive?'本轮已出局':isRevealedIdiot(p)?'已翻牌':(highest?'★ 最高 · ':'')+'来自'+incoming.length+'人'}</span></span></button>`;}).join('');
  fitVisibleGrid();
}
function editSavedVote(){const p=gameTools().polls.find(x=>x.id===ui.resultId);if(!p)return;ui.reviewId=null;ui.draftKey='edit-'+p.id;gameTools().drafts[ui.draftKey]={round:p.round,phase:p.phase,ballots:clone(p.ballots),selected:p.roster.find(canVote)?.id??null,savedId:p.id,roster:clone(p.roster),undo:[],sheriffId:p.sheriffId??null,sheriffWeight:p.sheriffWeight??1.5,weightVersion:p.weightVersion??0};showTool('vote');renderVoting();persistTools();}
function startNextVoteRound(){ui.reviewId=null;ui.draftKey=voteDraftKey();gameTools().drafts[ui.draftKey]=createVoteDraft();showTool('vote');renderVoting();persistTools();}
function openVoteReview(){const p=gameTools().polls.find(x=>x.id===ui.resultId);if(!p)return;ui.reviewId=p.id;ui.reviewVoter=p.roster.find(canVote)?.id??null;showTool('vote');renderVoting();}
function showPollIncoming(id,pid){
  const p=gameTools().polls.find(x=>x.id===id);if(!p)return;const r=tallyVotes(p),receiver=p.roster.find(x=>x.id===pid),incoming=r.incoming[pid]||[];
  $('pollDetailContent').innerHTML=`<div class="sheet-tool-heading"><h3>${esc(playerName(receiver))} · ${r.totals[pid]}票</h3><button class="btn blue tool-back" onclick="returnToGame()">↩ 返回对局</button></div><div class="tool-caption">${roundLabel(p.round,p.phase)} 第${p.number}轮 · 投票来源</div><div class="poll-chip-list">${incoming.length?incoming.map(id=>{const source=p.roster.find(x=>x.id===id);return `<span class="chip">${esc(playerName(source))}${source.id===p.sheriffId?' ★警长':''} · ${pollVoteWeight(p,source.id)}票</span>`;}).join(''):'<span class="tool-caption">无人投给该玩家</span>'}</div><button class="btn blue" onclick="closePollDetail();openVoteReview()">查看逐人投向</button>`;
  $('pollDetailOverlay').classList.add('show');$('pollDetailSheet').classList.add('show');
}
function closePollDetail(){$('pollDetailOverlay').classList.remove('show');$('pollDetailSheet').classList.remove('show');}

/* ================= 号码牌 ================= */
function openNumberPicker(){if(!state.started){toast('请先开局');return;}hideNumberScreen();showTool('numbers');$('numberPickerGrid').innerHTML=state.players.map(p=>`<button class="vote-tile ${p.alive?'':'inactive'}" onclick="showPlayerNumber(${p.id},'picker')"><span class="avatar" style="background:${participantColor(p)}">${p.id}</span><span class="tile-info"><span class="tile-state">${p.alive?'点击展示':'已出局 · 可展示'}</span></span></button>`).join('');fitVisibleGrid();}
function showPlayerNumber(pid,origin='game'){
  const p=state.players.find(x=>x.id===pid);if(!p)return;closeToolSheets();ui.numberPid=pid;ui.numberOrigin=origin;
  $('numberDigit').textContent=pid;$('numberScreen').style.background=participantColor(p);$('numberScreen').hidden=false;document.body.classList.add('number-open');
  const index=state.players.findIndex(x=>x.id===pid);$('numberPrev').disabled=index<=0;$('numberNext').disabled=index>=state.players.length-1;
  revealNumberControls();syncAwake();
  if(window.AndroidHost?.setFullScreen)try{AndroidHost.setFullScreen(true);}catch(e){}
  else if(!document.fullscreenElement&&$('numberScreen').requestFullscreen)$('numberScreen').requestFullscreen().catch(()=>{});
}
function changeNumber(direction){const i=state.players.findIndex(p=>p.id===ui.numberPid),p=state.players[i+direction];if(p)showPlayerNumber(p.id,ui.numberOrigin);}
function revealNumberControls(){$('numberControls').classList.remove('dimmed');clearTimeout(numberControlsTimer);numberControlsTimer=setTimeout(()=>{if(!ui.numberPid||$('numberControls').contains(document.activeElement))return;$('numberControls').classList.add('dimmed');},3200);}
function hideNumberScreen(){const wasOpen=ui.numberPid!=null;ui.numberPid=null;clearTimeout(numberControlsTimer);$('numberScreen').hidden=true;document.body.classList.remove('number-open');if(wasOpen){if(window.AndroidHost?.setFullScreen)try{AndroidHost.setFullScreen(false);}catch(e){}if(document.fullscreenElement)document.exitFullscreen().catch(()=>{});}syncAwake();}
function exitNumberDisplay(){const origin=ui.numberOrigin;hideNumberScreen();if(origin==='picker')openNumberPicker();else returnToGame();}
function numberChooseAgain(){hideNumberScreen();openNumberPicker();}
let numberTouchX=null;
$('numberScreen').addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;numberTouchX=e.clientX;revealNumberControls();});
$('numberScreen').addEventListener('pointerup',e=>{if(numberTouchX==null)return;const delta=e.clientX-numberTouchX;numberTouchX=null;if(Math.abs(delta)>60)changeNumber(delta<0?1:-1);});
document.addEventListener('fullscreenchange',()=>{if(ui.numberPid&&!document.fullscreenElement&&!window.AndroidHost)exitNumberDisplay();});

/* ================= 结算 ================= */
function requestEndGame(){
  if(!state.started){toast('请先开局');return;}showConfirm('结束本局并公开身份？','结算将展示所有玩家身份与出局情况，并暂停当前计时。\n对局记录及投票历史会保留。',()=>{snapshot();state.finished=true;state.endedAt=Date.now();state.endRound=roundLabel();addLog('系统',null,'📋 本局结束，展示身份与出局情况');pauseTimerSilently();save();openSettlement(true);});
}
function openSettlement(confirmed=false){
  if(!state.started){toast('请先开局');return;}
  if(!confirmed&&!state.finished){showConfirm('公开本局身份？','本局结算页会显示所有人的身份、出局情况和投票记录。',()=>openSettlement(true));return;}
  showTool('settlement');$('settlementRound').textContent=state.players.length+'人局 · '+(state.finished?state.endRound+'结束':roundLabel()+' · 核对预览');
  $('settlementGrid').innerHTML=state.players.map(p=>`<div class="card ${p.alive?'':'dead'}"><div class="avatar" style="background:${participantColor(p)}">${p.id}${sheriffMark(p)}</div>${roleBadge(p)}<div class="settlement-death">${p.alive?(isRevealedIdiot(p)?'已翻牌 · 存活':'😊 存活'):`${esc(p.deathRound||'时间未记录')}<br>${CAUSE_EMOJI[p.cause]||'💀'} ${esc(p.cause||'死因未记录')}`}</div></div>`).join('');
  const polls=gameTools().polls;$('settlementVotes').className='poll-list';$('settlementVotes').innerHTML=polls.length?polls.map(p=>{const t=tallyVotes(p);return `<button class="poll-history-button ${t.tied?'tied':''}" onclick="showVoteResult('${p.id}')">${roundLabel(p.round,p.phase)} · 第${p.number}轮<br>${t.max?(t.tied?'⚠️ 平票：':'最高票：')+t.leaders.map(id=>id+'号').join('、')+' · '+(t.tied?'各':'')+t.max+'票':'尚无有效选票'}<span class="tool-caption">　已记录 ${t.recorded}/${t.voters} · 查看明细 ›</span></button>`;}).join(''):'<div class="tool-caption">本局尚未保存投票结果。</div>';
}

/* ================= 计时：基于实际时间，关闭窗口不会停止 ================= */
function elapsedTimer(){const t=extra.timer;return Math.max(0,t.elapsed+(t.status==='running'?Math.max(0,Date.now()-t.anchor):0));}
function timerRemaining(){return Math.max(0,extra.timer.duration-elapsedTimer());}
function timerFormat(ms,roundUp=false){const s=Math.max(0,roundUp?Math.ceil(ms/1000):Math.floor(ms/1000)),h=Math.floor(s/3600),m=Math.floor(s/60)%60;return (h?String(h).padStart(2,'0')+':':'')+String(m).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}
function timerToken(){return Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8);}
function openTimer(){ensureAlarmAudio();closeSheet();closeSetup();closeLog();$('timerOverlay').classList.add('show');$('timerSheet').classList.add('show');renderTimerInputs();renderTimerPresets();renderTimerClock();}
function closeTimer(){$('timerOverlay').classList.remove('show');$('timerSheet').classList.remove('show');}
function renderTimerInputs(){
  const t=extra.timer;$('timerDown').className='btn '+(t.mode==='down'?'green':'ghost');$('timerUp').className='btn '+(t.mode==='up'?'green':'ghost');
  const seconds=Math.round(t.duration/1000);$('timerMinutes').value=Math.floor(seconds/60);$('timerSeconds').value=seconds%60;
  ['color','sound','vibrate','countdownSound'].forEach(k=>$('timer'+k[0].toUpperCase()+k.slice(1)).checked=t[k]);$('timerTarget').checked=t.upTarget;$('timerTargetWrap').hidden=t.mode!=='up';$('timerWarning').value=t.warning;$('timerCountdownWrap').hidden=t.mode!=='down';$('timerCountdownSound').disabled=!t.sound;
}
function renderTimerClock(){
  const t=extra.timer,elapsed=elapsedTimer(),remaining=Math.max(0,t.duration-elapsed),done=t.status==='done',warning=t.status==='running'&&t.mode==='down'&&remaining>0&&remaining<=t.warning*1000;
  $('timerClock').textContent=timerFormat(t.mode==='down'?remaining:elapsed,t.mode==='down');
  $('timerState').textContent=done?'⏰ 时间到':t.status==='running'?(warning?'即将到时':t.mode==='down'?'倒计时中':'正计时中'):t.status==='paused'?'已暂停':'准备开始';
  $('timerFace').classList.toggle('warning',t.color&&warning);$('timerFace').classList.toggle('done',t.color&&(done||t.mode==='up'&&t.notified));
  $('timerStart').textContent=t.status==='running'?'Ⅱ 暂停':t.status==='paused'?'▶ 继续':done?'↻ 再来一次':'▶ 开始';
  $('btnTimer').classList.toggle('running',t.status==='running');$('btnTimer').classList.toggle('timer-done',done||t.notified);
  $('btnTimer').setAttribute('aria-label','计时器，'+$('timerClock').textContent+'，'+$('timerState').textContent);
}
function ensureAlarmAudio(){try{if(!audioContext||audioContext.state==='closed'){const A=window.AudioContext||window.webkitAudioContext;if(A)audioContext=new A();}if(audioContext&&audioContext.state!=='running')audioContext.resume().catch(()=>{});return audioContext;}catch(e){return null;}}
function rememberReminderChannel(key){if(webReminderChannels.has(key))return false;webReminderChannels.add(key);if(webReminderChannels.size>128)webReminderChannels.delete(webReminderChannels.values().next().value);return true;}
function playWebTimerReminder(request){
  if(request.sound){const ctx=ensureAlarmAudio();if(ctx){const play=()=>{
    if(ctx.state!=='running'||!rememberReminderChannel(request.token+'-sound'))return;
    try{[[1760,.26],[3525,.10],[5285,.045]].forEach(([frequency,volume])=>{const o=ctx.createOscillator(),g=ctx.createGain(),now=ctx.currentTime;o.frequency.value=frequency;g.gain.setValueAtTime(0,now);g.gain.linearRampToValueAtTime(volume,now+.006);g.gain.exponentialRampToValueAtTime(.0001,now+1.35);o.connect(g);g.connect(ctx.destination);o.start(now);o.stop(now+1.4);});}catch(e){}
  };if(ctx.state==='running')play();else ctx.resume().then(play).catch(()=>{});}}
  if(request.vibrate&&navigator.vibrate&&rememberReminderChannel(request.token+'-vibrate'))try{navigator.vibrate([300,150,300,150,450]);}catch(e){}
}
function dispatchTimerReminder(request,nativeAlreadyPlayed=false){
  reminderRequest=request;if(nativeAlreadyPlayed)return;
  if(window.AndroidHost?.alertTimer){try{AndroidHost.alertTimer(request.token,request.sound,request.vibrate);return;}catch(e){}}
  playWebTimerReminder(request);
}
function playTimerReminder(nativeAlreadyPlayed=false){const t=extra.timer;dispatchTimerReminder({token:t.token,sound:!!t.sound,vibrate:!!t.vibrate},nativeAlreadyPlayed);}
function nativeTimerSoundFailed(token){if(reminderRequest?.token===token&&reminderRequest.sound)playWebTimerReminder({token,sound:true,vibrate:false});}
function testTimerReminder(){const t=extra.timer;if(!t.sound&&!t.vibrate){toast('请先开启音效或振动');return;}ensureAlarmAudio();dispatchTimerReminder({token:'preview-'+timerToken(),sound:!!t.sound,vibrate:!!t.vibrate});toast('测试提醒 · '+[t.sound?'音效':'',t.vibrate?'振动':''].filter(Boolean).join('、'));}
function finishTimer(nativeAlreadyPlayed=false){
  const t=extra.timer;if(t.notified)return;t.notified=true;if(t.mode==='down'){t.elapsed=t.duration;t.anchor=0;t.status='done';}
  persistTools();playTimerReminder(nativeAlreadyPlayed);syncNativeTimer();renderTimerClock();toast('⏰ 时间到');
}
function countdownEnabled(){const t=extra.timer;return t.status==='running'&&t.mode==='down'&&t.sound&&t.countdownSound&&t.warning>0&&!t.notified;}
function playCountdownCue(token,second){
  const t=extra.timer;if(t.token!==token||!countdownEnabled()||second<1||second>t.warning)return;
  const ctx=ensureAlarmAudio();if(!ctx)return;const play=()=>{
    if(ctx.state!=='running'||t.token!==token||!countdownEnabled()||!rememberReminderChannel(token+'-tick-'+second))return;
    try{const o=ctx.createOscillator(),g=ctx.createGain(),now=ctx.currentTime;o.frequency.value=820;g.gain.setValueAtTime(0,now);g.gain.linearRampToValueAtTime(.12,now+.005);g.gain.exponentialRampToValueAtTime(.0001,now+.085);o.connect(g);g.connect(ctx.destination);o.start(now);o.stop(now+.1);}catch(e){}
  };if(ctx.state==='running')play();else ctx.resume().then(play).catch(()=>{});
}
function nativeCountdownSoundFailed(token,second){playCountdownCue(token,second);}
function timerTick(){const t=extra.timer;if(t.status==='running'&&!t.notified&&(t.mode==='down'||t.upTarget)&&elapsedTimer()>=t.duration)finishTimer(false);else if(!nativeCountdownScheduled&&countdownEnabled())playCountdownCue(t.token,Math.ceil(timerRemaining()/1000));if($('timerSheet').classList.contains('show')||t.status==='running')renderTimerClock();}
function syncNativeTimer(){
  const t=extra.timer,active=t.status==='running'&&!t.notified&&(t.mode==='down'||t.upTarget),delay=active?Math.max(0,t.duration-elapsedTimer()):-1;nativeCountdownScheduled=false;let accepted=false;
  if(window.AndroidHost?.scheduleTimerV2)try{AndroidHost.scheduleTimerV2(t.token,delay,!!t.sound,!!t.vibrate,countdownEnabled(),t.warning);nativeCountdownScheduled=countdownEnabled();accepted=true;}catch(e){}
  if(!accepted&&window.AndroidHost?.scheduleTimer)try{AndroidHost.scheduleTimer(t.token,delay,!!t.sound,!!t.vibrate);}catch(e){}
  syncAwake();
}
function syncAwake(){
  const awake=extra.timer.status==='running'||ui.numberPid!=null;
  if(window.AndroidHost?.setKeepAwake)try{AndroidHost.setKeepAwake(awake);}catch(e){}
  else if(awake&&navigator.wakeLock&&document.visibilityState==='visible'&&!keepAwakeHandle)navigator.wakeLock.request('screen').then(h=>{keepAwakeHandle=h;h.addEventListener('release',()=>{keepAwakeHandle=null;});}).catch(()=>{});
  else if(!awake&&keepAwakeHandle){keepAwakeHandle.release().catch(()=>{});keepAwakeHandle=null;}
}
function toggleTimer(){
  const t=extra.timer;ensureAlarmAudio();
  if(t.status==='running'){t.elapsed=elapsedTimer();t.anchor=0;t.status='paused';}
  else{if(t.mode==='down'&&t.duration<=0){toast('请先设置大于0的时长');return;}if(t.status==='done'){t.elapsed=0;t.notified=false;}if(t.status==='idle'){t.elapsed=0;t.notified=false;}t.status='running';t.anchor=Date.now();t.token=timerToken();}
  persistTools();syncNativeTimer();renderTimerClock();
}
function resetTimer(){const t=extra.timer;t.status='idle';t.anchor=0;t.elapsed=0;t.notified=false;t.token=timerToken();persistTools();syncNativeTimer();renderTimerInputs();renderTimerClock();}
function pauseTimerSilently(){const t=extra.timer;if(t.status==='running'){t.elapsed=elapsedTimer();t.anchor=0;t.status='paused';persistTools();syncNativeTimer();renderTimerClock();}}
function setTimerMode(mode){if(extra.timer.mode===mode)return;pauseTimerSilently();extra.timer.mode=mode;resetTimer();}
function updateDuration(seconds){
  const t=extra.timer;t.duration=Math.min(359999000,Math.max(0,Math.round(seconds*1000)));
  if(t.status==='done'){t.status='idle';t.elapsed=0;t.anchor=0;}t.notified=false;t.token=timerToken();
  persistTools();syncNativeTimer();timerTick();renderTimerInputs();renderTimerClock();
}
function adjustTimer(seconds){updateDuration(extra.timer.duration/1000+seconds);}
function timerInputChanged(){const min=Math.max(0,Math.floor(Number($('timerMinutes').value)||0)),sec=Math.max(0,Math.floor(Number($('timerSeconds').value)||0));updateDuration(min*60+sec);}
function setTimerOption(key,value){extra.timer[key]=!!value;persistTools();syncNativeTimer();renderTimerInputs();renderTimerClock();}
function setTimerWarning(value){extra.timer.warning=Math.min(3600,Math.max(0,Math.floor(Number(value)||0)));persistTools();$('timerWarning').value=extra.timer.warning;syncNativeTimer();renderTimerClock();}
function startPreset(id){const preset=extra.timer.presets.find(p=>p.id===id);if(!preset)return;const apply=()=>{extra.timer.status='idle';extra.timer.elapsed=0;extra.timer.anchor=0;extra.timer.duration=preset.seconds*1000;extra.timer.notified=false;renderTimerInputs();toggleTimer();};if(extra.timer.status==='running')showConfirm('切换常用时长？','当前计时将重新开始。',apply);else apply();}
function renderTimerPresets(){const classes=['orange','purple','blue','teal','green'];$('timerPresets').innerHTML=extra.timer.presets.map((p,i)=>`<button class="btn ${classes[i%classes.length]}" data-preset="${p.id}" aria-label="${esc(p.name)}，${timerFormat(p.seconds*1000)}；长按可编辑">${esc(p.name)}</button>`).join('');}
function saveTimerPreset(){const sec=Math.round(extra.timer.duration/1000);if(sec<1){toast('常用时间至少为1秒');return;}const p={id:'preset-'+timerToken(),name:sec%60===0?sec/60+'分钟':timerFormat(sec*1000),seconds:sec};extra.timer.presets.push(p);persistTools();renderTimerPresets();toast('已保存，长按卡片可编辑或删除');}
function editTimerPreset(id){const p=extra.timer.presets.find(x=>x.id===id);if(!p)return;ui.presetId=id;$('presetName').value=p.name;$('presetMinutes').value=Math.floor(p.seconds/60);$('presetSeconds').value=p.seconds%60;$('presetOverlay').classList.add('show');$('presetSheet').classList.add('show');}
function closePresetEditor(){$('presetOverlay').classList.remove('show');$('presetSheet').classList.remove('show');ui.presetId=null;}
function applyTimerPresetEdit(){const p=extra.timer.presets.find(x=>x.id===ui.presetId);if(!p)return;const seconds=Math.floor(Number($('presetMinutes').value)||0)*60+Math.floor(Number($('presetSeconds').value)||0);if(seconds<=0||seconds>359999){toast('请填写1秒至99小时59分59秒的时间');return;}p.name=$('presetName').value.trim()||timerFormat(seconds*1000);p.seconds=seconds;persistTools();closePresetEditor();renderTimerPresets();}
function deleteTimerPreset(){const id=ui.presetId;showConfirm('删除这张常用时间卡？','只删除此快捷时长，不会停止正在运行的计时。',()=>{extra.timer.presets=extra.timer.presets.filter(p=>p.id!==id);persistTools();closePresetEditor();renderTimerPresets();});}
let holdTimeout=0,holdInterval=0,heldPreset=false;
function stopHold(){clearTimeout(holdTimeout);clearInterval(holdInterval);holdTimeout=holdInterval=0;}
document.querySelectorAll('[data-hold-seconds]').forEach(button=>{button.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();stopHold();button.setPointerCapture?.(e.pointerId);adjustTimer(Number(button.dataset.holdSeconds));holdTimeout=setTimeout(()=>{holdInterval=setInterval(()=>adjustTimer(Number(button.dataset.holdSeconds)),90);},420);});button.addEventListener('pointerup',stopHold);button.addEventListener('pointercancel',stopHold);button.addEventListener('lostpointercapture',stopHold);button.addEventListener('click',e=>{if(e.detail===0)adjustTimer(Number(button.dataset.holdSeconds));});});
$('timerPresets').addEventListener('pointerdown',e=>{const b=e.target.closest('[data-preset]');if(!b)return;heldPreset=false;holdTimeout=setTimeout(()=>{heldPreset=true;editTimerPreset(b.dataset.preset);},550);});
$('timerPresets').addEventListener('pointerup',stopHold);$('timerPresets').addEventListener('pointercancel',stopHold);
$('timerPresets').addEventListener('click',e=>{const b=e.target.closest('[data-preset]');if(b&&!heldPreset)startPreset(b.dataset.preset);heldPreset=false;});
$('timerPresets').addEventListener('contextmenu',e=>{const b=e.target.closest('[data-preset]');if(b){e.preventDefault();editTimerPreset(b.dataset.preset);}});
function nativeTimerFired(token){if(extra.timer.token===token&&extra.timer.status==='running')finishTimer(true);}
function nativeReady(){syncNativeTimer();renderTimerClock();}
function resetToolForGame(){returnToGame();resetTimer();}
function handleAppBack(){
  if($('confirmBox').classList.contains('show')){closeConfirm();return true;}
  if($('roleTargetSheet').classList.contains('show')){closeRoleTarget();return true;}
  if($('presetSheet').classList.contains('show')){closePresetEditor();return true;}
  if($('pollDetailSheet').classList.contains('show')){closePollDetail();return true;}
  if($('timerSheet').classList.contains('show')){closeTimer();return true;}
  if($('actionSheet').classList.contains('show')){closeSheet();return true;}
  if($('logSheet').classList.contains('show')){closeLog();return true;}
  if($('setupSheet').classList.contains('show')){closeSetup();return true;}
  if(ui.numberPid!=null){exitNumberDisplay();return true;}
  if(ui.page==='vote'&&ui.reviewId){showVoteResult(ui.reviewId);return true;}
  if(ui.page){returnToGame();return true;}return false;
}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&handleAppBack())e.preventDefault();});
window.addEventListener('resize',updateViewport);window.visualViewport?.addEventListener('resize',updateViewport);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'){timerTick();syncNativeTimer();syncAwake();updateViewport();}});
document.addEventListener('pointerdown',()=>{if(extra.timer.status==='running'&&extra.timer.sound)ensureAlarmAudio();},{passive:true});
$('btnVote').onclick=openVoting;$('btnNumbers').onclick=openNumberPicker;$('btnTimer').onclick=openTimer;
setInterval(timerTick,200);
