#!/usr/bin/env python3
"""Build a signed, dependency-free APK using the official Android SDK tools."""
import argparse
import hashlib
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--build-tools', type=Path, required=True, help='Android SDK build-tools/36.0.0')
parser.add_argument('--android-jar', type=Path, required=True, help='platforms/android-36/android.jar')
parser.add_argument('--ecj', type=Path, help='Optional Eclipse ECJ compiler JAR for a JRE-only environment')
parser.add_argument('--output', type=Path, default=ROOT / 'dist' / 'WerewolfJudge-1.3.0.apk')
args = parser.parse_args()
bt, android_jar, output = args.build_tools.resolve(), args.android_jar.resolve(), args.output.resolve()
if not android_jar.is_file():
    raise SystemExit('android.jar not found')
build = ROOT / 'build' / ('run-' + str(os.getpid()))
if build.exists():
    shutil.rmtree(build)
build.mkdir(parents=True)
output.parent.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()

def tool(name):
    suffix = '.bat' if os.name == 'nt' and name in ('d8', 'apksigner') else '.exe' if os.name == 'nt' else ''
    path = bt / (name + suffix)
    if not path.is_file():
        raise SystemExit(f'Missing build tool: {path}')
    return str(path)

def run(*cmd):
    subprocess.run([str(item) for item in cmd], check=True, cwd=ROOT, env=env)

print('Compiling Android resources...', flush=True)
if (ROOT / 'build_web.py').exists():
    run('python3', ROOT / 'build_web.py')
run(tool('aapt2'), 'compile', '--dir', ROOT / 'res', '-o', build / 'resources.zip')
run(tool('aapt2'), 'link', '-o', build / 'unsigned.apk',
    '-I', android_jar, '--manifest', ROOT / 'AndroidManifest.xml',
    '--java', build / 'generated', '-A', ROOT / 'assets', build / 'resources.zip')
print('Compiling Java and DEX...', flush=True)
classes = build / 'classes'
classes.mkdir()
sources = sorted((ROOT / 'src').rglob('*.java')) + sorted((build / 'generated').rglob('*.java'))
if args.ecj:
    run('java', '-jar', args.ecj.resolve(), '-1.8', '-encoding', 'UTF-8',
        '-classpath', android_jar, '-d', classes, *sources)
else:
    run('javac', '--release', '8', '-encoding', 'UTF-8', '-classpath', android_jar,
        '-d', classes, *sources)
with zipfile.ZipFile(build / 'classes.jar', 'w', zipfile.ZIP_DEFLATED) as jar:
    for path in sorted(classes.rglob('*.class')):
        jar.write(path, path.relative_to(classes).as_posix())
dex = build / 'dex'
dex.mkdir()
run(tool('d8'), '--release', '--min-api', '24', '--lib', android_jar,
    '--output', dex, build / 'classes.jar')
with zipfile.ZipFile(build / 'unsigned.apk', 'a', zipfile.ZIP_DEFLATED) as apk:
    for path in sorted(dex.glob('*.dex')):
        apk.write(path, path.name)

print('Aligning and signing APK...', flush=True)
run(tool('zipalign'), '-P', '16', '-f', '4', build / 'unsigned.apk', build / 'aligned.apk')
signing = ROOT / 'signing'
signing.mkdir(mode=0o700, exist_ok=True)
keystore, password_file = signing / 'release.jks', signing / 'password.txt'
if keystore.exists() != password_file.exists():
    raise SystemExit('Signing backup is incomplete: restore both release.jks and password.txt.')
if not keystore.exists():
    password_file.write_text(secrets.token_urlsafe(32), encoding='utf-8')
    password_file.chmod(0o600)
env['APK_SIGNING_PASSWORD'] = password_file.read_text(encoding='utf-8').strip()
if not keystore.exists():
    run('keytool', '-genkeypair', '-keystore', keystore, '-storetype', 'JKS',
        '-alias', 'werewolf-judge', '-keyalg', 'RSA', '-keysize', '3072',
        '-validity', '10000', '-dname', 'CN=Werewolf Judge, OU=Personal App, O=Rat',
        '-storepass:env', 'APK_SIGNING_PASSWORD', '-keypass:env', 'APK_SIGNING_PASSWORD')
    keystore.chmod(0o600)
run(tool('apksigner'), 'sign', '--ks', keystore, '--ks-key-alias', 'werewolf-judge',
    '--ks-pass', 'env:APK_SIGNING_PASSWORD', '--key-pass', 'env:APK_SIGNING_PASSWORD',
    '--v4-signing-enabled', 'false', '--out', output, build / 'aligned.apk')
print('Verifying signature, alignment and bundled content...', flush=True)
run(tool('apksigner'), 'verify', '--verbose', '--print-certs', output)
run(tool('zipalign'), '-c', '-P', '16', '4', output)
with zipfile.ZipFile(output) as apk:
    assert apk.read('assets/index.html') == (ROOT / 'assets/index.html').read_bytes()
    assert apk.read('classes.dex').startswith(b'dex\n')
    assert 'resources.arsc' in apk.namelist()
print(f'APK: {output}')
print(f'Size: {output.stat().st_size} bytes')
print(f'SHA-256: {hashlib.sha256(output.read_bytes()).hexdigest()}')
