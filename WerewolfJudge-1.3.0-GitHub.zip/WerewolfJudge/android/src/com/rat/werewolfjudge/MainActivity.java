package com.rat.werewolfjudge;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.res.AssetFileDescriptor;
import android.graphics.Color;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.os.VibrationAttributes;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.ToneGenerator;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.window.OnBackInvokedDispatcher;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashSet;
import org.json.JSONObject;

/** Offline shell. The original HTML is packaged byte-for-byte in assets/index.html. */
public final class MainActivity extends Activity {
    private static final String LOCAL_ORIGIN = "https://appassets.androidplatform.net/";
    private WebView webView;
    private FrameLayout root;
    private boolean night;
    private boolean exitPromptOpen;
    private boolean nativeFullScreen;
    private final Handler alarmHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingAlarm;
    private String scheduledAlarmToken = "";
    private final LinkedHashSet<String> deliveredAlarmTokens = new LinkedHashSet<>();
    private final Handler reminderHandler = new Handler(Looper.getMainLooper());
    private MediaPlayer alarmPlayer;
    private String currentSoundToken = "";
    private ToneGenerator alarmTone;
    private final Handler countdownHandler = new Handler(Looper.getMainLooper());
    private final LinkedHashSet<String> deliveredCountdownCues = new LinkedHashSet<>();
    private ToneGenerator countdownTone;
    private String countdownToken = "";

    @Override
    @SuppressLint("SetJavaScriptEnabled")
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setVolumeControlStream(AudioManager.STREAM_ALARM);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(232, 246, 255));
        setContentView(root);
        configureInsets();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.TRANSPARENT);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setBlockNetworkLoads(true);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setTextZoom(100);
        if (Build.VERSION.SDK_INT >= 33) settings.setAlgorithmicDarkeningAllowed(false);
        webView.addJavascriptInterface(new NativeBridge(), "AndroidHost");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return true; // This app only shows its bundled document.
            }

            // Keep the default resource loader: loadDataWithBaseURL also generates
            // an internal data: request. Rejecting every request here breaks startup.
            // Network access is already disabled by settings and the manifest.

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!url.startsWith(LOCAL_ORIGIN)) return;
                view.evaluateJavascript(
                    "(function(){" +
                    "window.copyLogs=function(){" +
                    "if(!state.logs.length){toast('还没有日志');return;}" +
                    "AndroidHost.copyText(state.logs.map(function(l){return l.detail;}).join('\\n'));" +
                    "};" +
                    "function syncTheme(){AndroidHost.setNightMode(document.body.classList.contains('night'));}" +
                    "syncTheme();new MutationObserver(syncTheme).observe(document.body,{attributes:true,attributeFilter:['class']});" +
                    "if(typeof nativeReady==='function')nativeReady();" +
                    "})();", null);
            }
        });
        setNativeTheme(false);
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::handleBack);
        }
        try (InputStream input = getAssets().open("index.html");
             ByteArrayOutputStream data = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) data.write(buffer, 0, count);
            webView.loadDataWithBaseURL(LOCAL_ORIGIN,
                    new String(data.toByteArray(), StandardCharsets.UTF_8), "text/html", "UTF-8", LOCAL_ORIGIN);
        } catch (Exception error) {
            TextView message = new TextView(this);
            message.setText("页面加载失败，请关闭应用后重试。");
            message.setPadding(32, 64, 32, 32);
            root.addView(message);
        }
    }

    private void configureInsets() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets safe = insets.getInsets(nativeFullScreen ? WindowInsets.Type.ime()
                        : WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                return WindowInsets.CONSUMED;
            });
            root.requestApplyInsets();
        } else {
            root.setFitsSystemWindows(true);
        }
    }

    @SuppressWarnings("deprecation")
    private void setNativeTheme(boolean isNight) {
        night = isNight;
        int background = isNight ? Color.rgb(13, 21, 48) : Color.rgb(232, 246, 255);
        root.setBackgroundColor(background);
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                controller.setSystemBarsAppearance(isNight ? 0 : mask, mask);
            }
        } else {
            getWindow().setStatusBarColor(background);
            getWindow().setNavigationBarColor(isNight ? background : Color.WHITE);
            int flags = isNight ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26 && !isNight) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            if (nativeFullScreen) flags |= View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    public final class NativeBridge {
        @JavascriptInterface
        public void copyText(String text) {
            runOnUiThread(() -> {
                try {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    clipboard.setPrimaryClip(ClipData.newPlainText("狼人杀行动日志", text));
                    webView.evaluateJavascript("toast('📋 日志已复制')", null);
                } catch (Exception error) {
                    webView.evaluateJavascript("toast('复制失败，请重试')", null);
                }
            });
        }

        @JavascriptInterface
        public void setNightMode(boolean value) {
            runOnUiThread(() -> setNativeTheme(value));
        }

        @JavascriptInterface
        public void setKeepAwake(boolean value) {
            runOnUiThread(() -> {
                if (value) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public void setFullScreen(boolean value) {
            runOnUiThread(() -> {
                nativeFullScreen = value;
                if (Build.VERSION.SDK_INT >= 30) {
                    WindowInsetsController controller = getWindow().getInsetsController();
                    if (controller != null) {
                        controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                        if (value) controller.hide(WindowInsets.Type.systemBars());
                        else controller.show(WindowInsets.Type.systemBars());
                    }
                }
                setNativeTheme(night);
                root.requestApplyInsets();
            });
        }

        @JavascriptInterface
        public void scheduleTimer(String token, double delay, boolean sound, boolean vibration) {
            scheduleNativeTimer(token, delay, sound, vibration, false, 0);
        }

        @JavascriptInterface
        public void scheduleTimerV2(String token, double delay, boolean sound, boolean vibration, boolean countdown, int fromSeconds) {
            scheduleNativeTimer(token, delay, sound, vibration, countdown, fromSeconds);
        }

        @JavascriptInterface
        public void alertTimer(String token, boolean sound, boolean vibration) {
            runOnUiThread(() -> deliverTimerAlarm(token, sound, vibration));
        }
    }

    private void cancelCountdown() {
        countdownHandler.removeCallbacksAndMessages(null);
        countdownToken = "";
        if (countdownTone != null) { try { countdownTone.release(); } catch (Exception ignored) { } countdownTone = null; }
    }

    private void scheduleNativeTimer(String token, double delay, boolean sound, boolean vibration, boolean countdown, int fromSeconds) {
        runOnUiThread(() -> {
            if (pendingAlarm != null) alarmHandler.removeCallbacks(pendingAlarm);
            pendingAlarm = null;
            cancelCountdown();
            scheduledAlarmToken = token == null ? "" : token;
            if (delay < 0 || !Double.isFinite(delay)) return;
            final String scheduled = scheduledAlarmToken;
            final long remaining = (long) Math.min(delay, 359999000);
            final long endAt = SystemClock.elapsedRealtime() + remaining;
            final int threshold = Math.max(0, Math.min(3600, fromSeconds));
            if (countdown && sound && threshold > 0 && remaining > 0) {
                countdownToken = scheduled;
                Runnable cue = new Runnable() {
                    @Override public void run() {
                        if (!scheduled.equals(countdownToken) || isFinishing()) return;
                        long left = endAt - SystemClock.elapsedRealtime();
                        if (left <= 0) return;
                        int second = (int) Math.ceil(left / 1000.0);
                        if (second <= threshold) playNativeCountdownCue(scheduled, second);
                        long next = second > threshold ? left - threshold * 1000L : left - (second - 1) * 1000L;
                        countdownHandler.postDelayed(this, Math.max(1, next));
                    }
                };
                countdownHandler.postDelayed(cue, Math.max(0, remaining - threshold * 1000L));
            }
            pendingAlarm = () -> {
                if (!scheduled.equals(scheduledAlarmToken)) return;
                pendingAlarm = null;
                cancelCountdown();
                deliverTimerAlarm(scheduled, sound, vibration);
                if (webView != null) webView.evaluateJavascript(
                        "if(typeof nativeTimerFired==='function')nativeTimerFired(" + JSONObject.quote(scheduled) + ");", null);
            };
            alarmHandler.postDelayed(pendingAlarm, remaining);
        });
    }

    private void playNativeCountdownCue(String token, int second) {
        String key = token + ":" + second;
        if (!deliveredCountdownCues.add(key)) return;
        if (deliveredCountdownCues.size() > 256) deliveredCountdownCues.remove(deliveredCountdownCues.iterator().next());
        try {
            if (countdownTone == null) countdownTone = new ToneGenerator(AudioManager.STREAM_ALARM, 50);
            if (countdownTone.startTone(ToneGenerator.TONE_PROP_BEEP, 75)) return;
        } catch (Exception ignored) { }
        if (webView != null) webView.evaluateJavascript(
                "if(typeof nativeCountdownSoundFailed==='function')nativeCountdownSoundFailed(" + JSONObject.quote(token) + "," + second + ");", null);
    }

    @SuppressWarnings("deprecation")
    private void deliverTimerAlarm(String token, boolean sound, boolean vibration) {
        if (token == null || token.isEmpty() || deliveredAlarmTokens.contains(token) || isFinishing()) return;
        if (token.equals(scheduledAlarmToken)) cancelCountdown();
        deliveredAlarmTokens.add(token);
        if (deliveredAlarmTokens.size() > 64) deliveredAlarmTokens.remove(deliveredAlarmTokens.iterator().next());
        if (sound) playAlarmSound(token);
        if (vibration) {
            try {
                Vibrator vibrator;
                if (Build.VERSION.SDK_INT >= 31) {
                    VibratorManager manager = (VibratorManager) getSystemService(VIBRATOR_MANAGER_SERVICE);
                    vibrator = manager == null ? null : manager.getDefaultVibrator();
                } else vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (vibrator != null && vibrator.hasVibrator()) {
                    long[] pattern = new long[]{0, 300, 150, 300, 150, 450};
                    if (Build.VERSION.SDK_INT >= 33) vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1),
                            new VibrationAttributes.Builder().setUsage(VibrationAttributes.USAGE_ALARM).build());
                    else if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1), alarmAudioAttributes());
                    else vibrator.vibrate(pattern, -1, alarmAudioAttributes());
                }
            } catch (Exception ignored) { }
        }
    }

    private AudioAttributes alarmAudioAttributes() {
        return new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
    }

    private void releasePlayer(MediaPlayer player) {
        if (alarmPlayer == player) alarmPlayer = null;
        try { player.release(); } catch (Exception ignored) { }
    }

    private void releaseAlarmAudio() {
        reminderHandler.removeCallbacksAndMessages(null);
        if (alarmPlayer != null) releasePlayer(alarmPlayer);
        if (alarmTone != null) { try { alarmTone.release(); } catch (Exception ignored) { } alarmTone = null; }
    }

    private void playAlarmSound(String token) {
        releaseAlarmAudio();
        currentSoundToken = token;
        final MediaPlayer player = new MediaPlayer();
        alarmPlayer = player;
        try (AssetFileDescriptor source = getResources().openRawResourceFd(R.raw.timer_alarm)) {
            player.setAudioAttributes(alarmAudioAttributes());
            player.setDataSource(source.getFileDescriptor(), source.getStartOffset(), source.getLength());
            player.setOnPreparedListener(ready -> {
                if (alarmPlayer != ready || !token.equals(currentSoundToken)) { releasePlayer(ready); return; }
                try { ready.start(); } catch (Exception error) { releasePlayer(ready); playFallbackTone(token); }
            });
            player.setOnCompletionListener(this::releasePlayer);
            player.setOnErrorListener((failed, what, extra) -> {
                releasePlayer(failed); playFallbackTone(token); return true;
            });
            player.prepareAsync();
        } catch (Exception error) { releasePlayer(player); playFallbackTone(token); }
    }

    private void playFallbackTone(String token) {
        if (!token.equals(currentSoundToken) || isFinishing()) return;
        releaseAlarmAudio();
        try {
            final ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_ALARM, 90);
            alarmTone = tone;
            for (int offset : new int[]{0, 300, 600, 900}) reminderHandler.postDelayed(() -> {
                if (alarmTone != tone) return;
                try {
                    if (!tone.startTone(ToneGenerator.TONE_PROP_BEEP, 180)) {
                        releaseAlarmAudio(); reportSoundFailure(token);
                    }
                } catch (Exception error) { releaseAlarmAudio(); reportSoundFailure(token); }
            }, offset);
            reminderHandler.postDelayed(this::releaseAlarmAudio, 1300);
        } catch (Exception error) { reportSoundFailure(token); }
    }

    private void reportSoundFailure(String token) {
        if (webView != null) webView.evaluateJavascript(
                "if(typeof nativeTimerSoundFailed==='function')nativeTimerSoundFailed(" + JSONObject.quote(token) + ");", null);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() { handleBack(); }

    private void handleBack() {
        if (webView == null || exitPromptOpen) return;
        webView.evaluateJavascript(
            "(function(){" +
            "if(typeof handleAppBack==='function')return handleAppBack();" +
            "if(document.getElementById('confirmBox').classList.contains('show')){closeConfirm();return true;}" +
            "if(document.getElementById('logSheet').classList.contains('show')){closeLog();return true;}" +
            "if(document.getElementById('setupSheet').classList.contains('show')){closeSetup();return true;}" +
            "if(document.getElementById('actionSheet').classList.contains('show')){closeSheet();return true;}" +
            "return false;})()", result -> {
                if (!"true".equals(result) && !isFinishing() && !exitPromptOpen) {
                    exitPromptOpen = true;
                    new AlertDialog.Builder(this)
                        .setTitle("退出狼人杀法官助手？")
                        .setMessage("已记录的对局会保留，下次打开可继续。")
                        .setNegativeButton("继续使用", (dialog, which) -> {})
                        .setPositiveButton("退出", (dialog, which) -> finish())
                        .setOnDismissListener(dialog -> exitPromptOpen = false)
                        .show();
                }
            });
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && root != null) setNativeTheme(night);
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        if (webView != null) webView.evaluateJavascript("if(typeof timerTick==='function')timerTick();", null);
    }

    @Override
    protected void onDestroy() {
        alarmHandler.removeCallbacksAndMessages(null);
        cancelCountdown();
        releaseAlarmAudio();
        if (webView != null) {
            root.removeView(webView);
            webView.removeJavascriptInterface("AndroidHost");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
